import { combineReducers } from "@reduxjs/toolkit";
import { persistReducer } from "redux-persist";
import LoginReducer from "./login/LoginSlice";
import storage from "redux-persist/lib/storage";
const persistConfig = {
    storage,
    key: 'demo-user',
    whitelist: ['userInfo']
}
const persistedLoginReducer = persistReducer(persistConfig, LoginReducer);

export const rootReducer = combineReducers({
    login: persistedLoginReducer
})