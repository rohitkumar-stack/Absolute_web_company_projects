import axios from 'axios';
import config from "../../config/Config";


export const Login = (payload) => {
    console.log("entry in crud");
    const configs = {
        headers: {
            'Content-Type': 'multipart/form-data'
        }
    };
    return axios.post(`${config.default.login}`, payload, configs);
}