import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';
import { Login } from './LoginCrud';

export const userLogin = createAsyncThunk(
    "Login/userLogin",
    async (payload, { rejectWithValue }) => {
        try {
            const res = await Login(payload);
            if (res?.status) {
                console.log(res,"ressss")
                return res?.data;
            } else {
                throw new Error(res?.message);
            }
        } catch (error) {
            return rejectWithValue(error.message);
        }
    }
)

const LoginSlice = createSlice({
    name: 'Login',
    initialState: {
        userInfo: {},
        userToken: '',
        isAuthenticated: false,
        isLoading: false,
        error: ''
    },
    reducers: {
        // Define your reducers here if you have any
    },
    extraReducers: (builder) => {
        builder
            .addCase(userLogin.pending, (state) => {
                state.isLoading = true;
                state.error = '';
            })
            .addCase(userLogin.fulfilled, (state, action) => {
                state.isLoading = false;
                state.userInfo = action.payload.data; // Make sure this aligns with your actual action payload structure
                // If 'data' should not be there, just use action.payload
            })
            .addCase(userLogin.rejected, (state, action) => {
                state.isLoading = false;
                state.error = action.error.message; // This correctly assigns the error message
            });
    }
})

export default LoginSlice.reducer;
