import React, { useState } from "react";
import { Row, Col, Form, Button } from "react-bootstrap";
import "./login.scss";
import bgimage from "../../assets/login/images/login-image.jpg";
import logo from "../../assets/login/images/logo.png";
import * as formik from 'formik';
import * as Yup from 'yup';
import { CiLock } from "react-icons/ci";
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from "react-router-dom";
import { LOGIN } from "../../config/Config"
import {LOGIN_URL} from "../../globals";
import { Link } from "react-router-dom";

const Login = () => {
    const { Formik } = formik;
    const dispatch = useDispatch();
    const navigate = useNavigate()
    const { isLoading, error } = useSelector((state) => state.login);
    const schema = Yup.object().shape({
        email: Yup.string().email('invalid email address').required('Email is required'),
        password: Yup.string()
            .test(
                'is-admin-or-long-enough',
                'Password should be "admin" or at least 8 characters in length',
                value => value === 'admin' || (value && value.length >= 8)
            )
            .required('Password is required'),

    });

    const handleSubmit = async (values) => {
        const formData = new FormData();

        formData.append("email", values.email);
        formData.append("password", values.password);

        try {
            const response = await fetch(LOGIN_URL,
                {
                    method: "POST",
                    body: formData,
                }
            );
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            // Handle successful response
            if (response.status === 200) {
                const responseData = await response.json();

                if (responseData.role_id == 'NxOpZowo9GmjKqdR') {

                    try {
                        // toast.success("Login successfully");
                        // console.log(responseData.access_token,"responseData")
                        localStorage.setItem("authToken", responseData.acess_token);
                        localStorage.setItem("authUser", JSON.stringify(responseData));
                        navigate('/dashboard')
                        await this.GetTheme();
                        await this.GetUserById(responseData.user_id);
                        // this.props.history.push("/dashboard");
                    } catch (error) {
                        console.error("Error storing data:", error);
                        // toast.error("Wrong Email-id and Password. Please try again later.");
                    }
                } else {
                    // toast("You are not authorized", {
                    //     type: "warning",
                    // });
                }
            }
        } catch (error) {
            console.error("Error:", error);
            // toast.error("Wrong Email-id and Password. Please try again later.");
            // Handle error
        }
    }

    return (
        <>
            <section>
                <Row className="row-main">
                    <Col md={4} >
                        <Row className="col-main">
                            <Col md={2}></Col>
                            <Col md={8} >
                                <div style={{ height: '100%', width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                    <div style={{ padding: '0' }}>
                                        <div style={{ textAlign: 'center' }}>

                                            <img src={logo} alt="image_svg"
                                                className="logo-single"
                                            />
                                            <p className="login-heading">Welcome Back !</p>
                                            <p className="login-paragraph">Sign in to continue to HRMS.</p>
                                        </div>
                                        <Formik
                                            validationSchema={schema}
                                            onSubmit={(values, { setSubmitting }) => {
                                                // Create a FormData object and append your values
                                                handleSubmit(values)

                                            }}
                                            initialValues={{
                                                email: '',
                                                password: '',
                                            }}
                                        >
                                            {({ handleSubmit, handleChange, values, touched, errors }) => {

                                                return (
                                                    <Form noValidate onSubmit={handleSubmit}>
                                                        <Row className="mb-3">
                                                            <Form.Group as={Col} md="12" controlId="validationFormik03">
                                                                <Form.Label>Email</Form.Label>
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                                <Form.Control
                                                                    type="email"
                                                                    name="email"
                                                                    value={values.email}
                                                                    onChange={handleChange}
                                                                    isInvalid={touched.email && !!errors.email}
                                                                />

                                                                <Form.Control.Feedback type="invalid">
                                                                    {errors.email}
                                                                </Form.Control.Feedback>
                                                            </Form.Group>

                                                            <Form.Group as={Col} md="12" controlId="validationFormik03" style={{ marginTop: "14px" }}>
                                                                <Form.Label>Password</Form.Label>
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                                <Form.Control
                                                                    type="password"
                                                                    name="password"
                                                                    value={values.password}
                                                                    onChange={handleChange}
                                                                    isInvalid={touched.password && !!errors.password}
                                                                />

                                                                <Form.Control.Feedback type="invalid">
                                                                    {errors.password}
                                                                </Form.Control.Feedback>
                                                            </Form.Group>
                                                            {error && <div className="alert alert-danger" role="alert">{error}</div>}
                                                            <Form.Group className="mb-12">
                                                                <Form.Check
                                                                    required
                                                                    // name="terms"
                                                                    className="remember-me"
                                                                    label="Remember me"
                                                                    onChange={handleChange}
                                                                    // isInvalid={!!error.terms}
                                                                    // feedback={error.terms}
                                                                    feedbackType="invalid"
                                                                    id="validationFormik0"
                                                                />
                                                            </Form.Group>
                                                        </Row>
                                                        <div style={{ textAlign: 'center' }}>
                                                            <Button className="btn btn-primary btn-lg btn-shadow" type="submit" disabled={isLoading}>
                                                                {isLoading ? 'Logging in...' : 'Login'}
                                                            </Button>
                                                        </div>
                                                        <div className="forgot-password-content">
                                                            <Link to="/ResetPassword" className="forgot_password">
                                                                <CiLock className="lock-icon" /> Forget Your password?
                                                            </Link>
                                                        </div>
                                                    </Form>
                                                )
                                            }}
                                        </Formik>
                                    </div>
                                </div>
                            </Col>
                            <Col md={2}></Col>
                        </Row>
                    </Col>
                    <Col md={8}>
                        <div className="image_right">
                            <img src={bgimage} className="bg-image" style={{ maxWidth: "100%", height: "100%", objectFit: 'cover' }} alt="alt" />
                        </div>
                    </Col>
                </Row>
            </section>
        </>
    );
}

export default Login;
