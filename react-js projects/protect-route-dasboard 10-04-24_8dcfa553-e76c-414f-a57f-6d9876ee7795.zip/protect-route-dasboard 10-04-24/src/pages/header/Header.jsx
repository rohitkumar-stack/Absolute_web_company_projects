import React, { useState } from 'react';
import { Row, Col, Button } from "react-bootstrap";
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import { FaUserCircle } from "react-icons/fa";
import { IoMdNotificationsOutline } from "react-icons/io";
import { FaEquals } from "react-icons/fa";
import logo from "../../assets/login/images/logo.png";
import "./headerStyle.scss";
import Dashborad from '../dashboard/Dashboard';
import { MdOutlineEmail } from "react-icons/md";
import { TbPointFilled } from "react-icons/tb";
import { CiSettings } from "react-icons/ci";
import { Link } from 'react-router-dom';

const Header = () => {
    const [showBasic, setShowBasic] = useState(false);

    return (
        <section>

            {/* start header */}
            <Row>
                <Col md={12} >
                    <header className='header-navbar'>
                        <Row>
                            <Col md={6}>
                                <Row>
                                    <Col md={1} ></Col>
                                    <Col md={3}>
                                        <img src={logo} alt="image_svg" className="logo-single" />
                                    </Col>
                                </Row>
                            </Col>
                            <Col md={6} className='user-profile-dropdown'>
                                <div className='dopdown-user'>
                                    <Row>

                                        <Col md={2}>
                                            <div className='notfication-icon'>
                                                <CiSettings className='notfication-icons' />

                                            </div>
                                        </Col>

                                        <Col md={2}>
                                            <div className='notfication-icon'>
                                                <MdOutlineEmail className='notfication-icons' />
                                                <span className='notification-number'>
                                                    <TbPointFilled />
                                                </span>
                                            </div>
                                        </Col>

                                        <Col md={2}>
                                            <div className='notfication-icon'>
                                                <IoMdNotificationsOutline className='notfication-icons' />
                                                <span className='notification-number'>
                                                    <TbPointFilled />
                                                </span>
                                            </div>
                                        </Col>

                                        <Col md={2}>
                                            <Dropdown className='user-dropdown-button'>
                                                <Dropdown.Toggle id="dropdown-example1">
                                                    <FaUserCircle className='user-profile-icon' />
                                                </Dropdown.Toggle>

                                                <Dropdown.Menu>
                                                    <Dropdown.Item href="#/action-1">
                                                        User
                                                    </Dropdown.Item>
                                                    <Dropdown.Item href="#/action-2">Profile</Dropdown.Item>
                                                    <Dropdown.Item >
                                                        Logout</Dropdown.Item>

                                                </Dropdown.Menu>
                                            </Dropdown>
                                        </Col>
                                        {/* <Col md={4}></Col> */}
                                        {/* <Col md={2}></Col> */}
                                    </Row>

                                </div>
                            </Col>
                        </Row>
                    </header>
                </Col>
            </Row>
            {/* End header */}

            {/* <section>
                <Row>
                    <Col md={1}></Col>
                    <Col md={10}>
                    <Dashborad/>
                    </Col>
                    <Col md={1}></Col>
                </Row>
            </section> */}


        </section>
    );
};

export default Header;
