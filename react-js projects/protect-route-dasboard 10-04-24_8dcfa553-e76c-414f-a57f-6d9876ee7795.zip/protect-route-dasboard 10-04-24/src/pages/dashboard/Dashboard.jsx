import { useLocation } from 'react-router-dom';

const Dashboard = () => {
  const location = useLocation();
  const { user } = location.state || {};

  return (
    <div className="home">
            <h1>Dashboard</h1>
        </div>
  );
};

export default Dashboard;