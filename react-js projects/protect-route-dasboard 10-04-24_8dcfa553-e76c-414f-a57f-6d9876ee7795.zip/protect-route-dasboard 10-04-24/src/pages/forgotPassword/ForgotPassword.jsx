import React from "react";
import { Row, Col, Form, Button } from "react-bootstrap";
// import "../login/loginstyle.scss";
import bgimage from "../../assets/login/images/login-image.jpg";
import logo from "../../assets/login/images/logo.png";
import * as formik from 'formik';
import * as Yup from 'yup';
import { CiLock } from "react-icons/ci";


const ForgotPassword = () => {
    const { Formik } = formik;

    const schema = Yup.object().shape({
        newPassword: Yup.string().required(),
        confirmPassword: Yup.string().required()
        // terms:Yup.bool().required().oneOf([true], 'Terms must be accepted'),

    });
    return (
        <>
            <section>
                <Row className="row-main">
                    <Col md={4} >
                        <Row className="col-main">
                            <Col md={2}></Col>
                            <Col md={8} >
                                <div style={{ height: '100%', width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                    <div style={{ padding: '0' }}>
                                        <div style={{ textAlign: 'center' }}>

                                            <img src={logo} alt="image_svg"
                                                className="logo-single"
                                            />
                                            <p className="login-heading">Forgot Password</p>
                                            <p className="login-paragraph">Forgot your password to HRMS.</p>
                                        </div>
                                        <Formik
                                            validationSchema={schema}
                                            onSubmit={console.log}
                                            initialValues={{
                                                newPassword:'',
                                                confirmPassword:'',

                                            }}
                                        >
                                            {({ handleSubmit, handleChange, values, touched, errors }) => (
                                                <Form noValidate onSubmit={handleSubmit}>
                                                    <Row className="mb-3">
                                                        <Form.Group as={Col} md="12" controlId="validationFormik03" style={{ marginTop: "14px" }}>
                                                            <Form.Label>New Password</Form.Label>
                                                            <span style={{ color: "#ff0000" }}>*</span>
                                                            <Form.Control
                                                                type="text"
                                                                placeholder="New Password"
                                                                name="newPassword"
                                                                value={values.newPassword}
                                                                onChange={handleChange}
                                                                isInvalid={!!errors.newPassword}
                                                            />

                                                            <Form.Control.Feedback type="invalid">
                                                                {errors.newPassword}
                                                            </Form.Control.Feedback>
                                                        </Form.Group>

                                                        <Form.Group as={Col} md="12" controlId="validationFormik03" style={{ marginTop: "14px" }}>
                                                            <Form.Label>Confirm Password</Form.Label>
                                                            <span style={{ color: "#ff0000" }}>*</span>
                                                            <Form.Control
                                                                type="text"
                                                                placeholder="Confirm Password"
                                                                name="confirmPassword"
                                                                value={values.confirmPassword}
                                                                onChange={handleChange}
                                                                isInvalid={!!errors.confirmPassword}
                                                            />

                                                            <Form.Control.Feedback type="invalid">
                                                                {errors.confirmPassword}
                                                            </Form.Control.Feedback>
                                                        </Form.Group>

                                                    </Row>
                                                    <div style={{ textAlign: 'center' }}>
                                                        <Button type="submit" className="btn btn-primary btn-lg btn-shadow" style={{ textAlign: "right" }}>Forgot Password</Button>
                                                    </div>

                                                </Form>
                                            )}
                                        </Formik>
                                    </div>
                                </div>
                            </Col>
                            <Col md={2}></Col>
                        </Row>
                    </Col>
                    <Col md={8}>
                        <div className="image_right">
                            <img src={bgimage} className="bg-image" style={{ maxWidth: "100%", height: "100%", objectFit: 'cover' }} alt="alt" />
                        </div>
                    </Col>
                </Row>
            </section>
        </>
    );
}

export default ForgotPassword;
