import React from "react";
import { Row, Col, Form, Button } from "react-bootstrap";
// import "../login/loginstyle.scss";
import bgimage from "../../assets/login/images/login-image.jpg";
import logo from "../../assets/login/images/logo.png";
import * as formik from 'formik';
import * as Yup from 'yup';
import { useNavigate, Link } from "react-router-dom";
import { ToastContainer, toast } from 'react-toastify';
import {RESET_PASSWORD_URL} from "../../globals";
import 'react-toastify/dist/ReactToastify.css';
import "./resetStyle.scss";



const ResetPassword = () => {
    const { Formik } = formik;

    const schema = Yup.object().shape({
        email: Yup.string().email('invalid email address').required('Email is required'),
    });


    const navigate = useNavigate()
    const notify = () => toast("Wow so easy!");

    const handleResetPasswordApi = async (values) => {
        const formData = new FormData();

        formData.append("email", values.email);

        try {
            const response = await fetch(RESET_PASSWORD_URL,
                {
                    method: "POST",
                    body: formData,
                }
            );
            if (!response.ok) {
                throw new Error("Network response was not ok");
            }
            // Handle successful response
            if (response.status === 200) {
                const responseData = await response.json();
                try {
                    navigate('/');
                    notify();

                } catch (error) {
                    console.error("Error storing data:", error);
                }

            }
        } catch (error) {
            console.error("Error:", error);
        }
    }

    return (
        <>
            <section>
                <Row className="row-main">
                    <Col md={4} >
                        <Row className="col-main">
                            <Col md={2}></Col>
                            <Col md={8} >
                                <div style={{ height: '100%', width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                    <div style={{ padding: '0' }}>
                                        <div style={{ textAlign: 'center' }}>

                                            <img src={logo} alt="image_svg"
                                                className="logo-single"
                                            />
                                            <p className="login-heading">Reset Password</p>
                                            <p className="login-paragraph">Reset your password to HRMS.</p>
                                        </div>
                                        <Formik
                                            validationSchema={schema}
                                            onSubmit={(values, { setSubmitting }) => {
                                                // Create a FormData object and append your values
                                                handleResetPasswordApi(values)

                                            }}

                                            initialValues={{
                                                email: '',

                                            }}
                                        >
                                            {({ handleSubmit, handleChange, values, touched, errors }) => (
                                                <Form noValidate onSubmit={handleSubmit}>
                                                    <Row className="mb-3">
                                                        <Form.Group as={Col} md="12" controlId="validationFormik03">
                                                            <Form.Label>Email</Form.Label>
                                                            <span style={{ color: "#ff0000" }}>*</span>
                                                            <Form.Control
                                                                type="text"
                                                                placeholder="Email"
                                                                name="email"
                                                                value={values.email}
                                                                onChange={handleChange}
                                                                isInvalid={!!errors.email}
                                                                style={{ width: "300px" }} // Adjust width as needed
                                                            />

                                                            <Form.Control.Feedback type="invalid">
                                                                {errors.email}
                                                            </Form.Control.Feedback>
                                                        </Form.Group>
                                                    </Row>
                                                    <div style={{ textAlign: 'center' }}>
                                                        <Button type="submit" className="btn btn-primary btn-lg btn-shadow" style={{ textAlign: "right" }}>RESET</Button>
                                                        <ToastContainer />
                                                    </div>


                                                    <div className="forgot-password-content">
                                                        <a href="#" className="forgot_password">
                                                            Already have an account?
                                                            <Link to="/"> <span style={{ color: "blue" }}>Login in</span></Link>
                                                        </a>
                                                    </div>

                                                </Form>
                                            )}
                                        </Formik>
                                    </div>
                                </div>
                            </Col>
                            <Col md={2}></Col>
                        </Row>
                    </Col>
                    <Col md={8}>
                        <div className="image_right">
                            <img src={bgimage} className="bg-image" style={{ maxWidth: "100%", height: "100%", objectFit: 'cover' }} alt="alt" />
                        </div>
                    </Col>
                </Row>
            </section>
        </>
    );
}

export default ResetPassword;
