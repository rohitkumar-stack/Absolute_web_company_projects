import React, { useState } from "react";
import { Row, Col, Button } from "react-bootstrap";
import styled from "styled-components";
import { Link } from "react-router-dom";
import * as FaIcons from "react-icons/fa";
import * as AiIcons from "react-icons/ai";
import SubMenu from "../subMenu/SubMenu";
import { IconContext } from "react-icons/lib";
import { SidebarData } from "../../data/sidebarData/SidebarData";
import Header from "../../pages/header/Header";
import Dropdown from 'react-bootstrap/Dropdown';
import DropdownButton from 'react-bootstrap/DropdownButton';
import { FaUserCircle } from "react-icons/fa";
import { IoMdNotificationsOutline } from "react-icons/io";
import { FaEquals } from "react-icons/fa";
import logo from "../../assets/login/images/logo.png";
import "../../pages/header/headerStyle.scss";
// import Dashborad from '../dashboard/Dashboard';
import { MdOutlineEmail } from "react-icons/md";
import { TbPointFilled } from "react-icons/tb";
import { CiSettings } from "react-icons/ci";
import {useNavigate} from "react-router-dom";

const Nav = styled.div`
    background: #F5F5F5;
    height: 80px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
`;

const NavIcon = styled(Link)`
    margin-left: 2rem;
    font-size: 2rem;
    height: 80px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
`;

const SidebarNav = styled.nav`
    background: #F5F5F5;
    width: 250px;
    height: 100vh;
    display: flex;
    justify-content: center;
    position: fixed;
    top: 0;
    left: ${({ sidebar }) => (sidebar ? "0" : "-100%")};
    transition: 350ms;
    z-index: 10;
`;

const SidebarWrap = styled.div`
    width: 100%;
`;

const Sidebar = () => {
    const [sidebar, setSidebar] = useState(true);
     
    //function
    const showSidebar = () => setSidebar(!sidebar);
 
    const navigate = useNavigate()
    //LogoutFunction
    const logoutfunctiom = () => {
        localStorage.clear();
        navigate("/");
        
    };
 

    return (
        <>
            <IconContext.Provider value={{ color: "black" }}>
                {/* start -header */}
                <Nav>
                    <Row>
                        <Col md={12} >
                            <header className='header-navbar'>
                                <Row>
                                    <Col md={6}>
                                        <Row>
                                            <Col md={2}>
                                                <img src={logo} alt="image_svg" className="logo-single" />
                                            </Col>
                                            <Col md={3}>
                                                <div className="equal-icons">
                                                    <Link to="#">
                                                        <FaIcons.FaBars onClick={showSidebar} className="equal-icons-content"
                                                        />
                                                    </Link>
                                                </div>
                                            </Col>
                                        </Row>
                                    </Col>
                                    <Col md={6} className='user-profile-dropdown'>
                                        <div className='dopdown-user'>
                                            <Row>

                                                <Col md={2}>
                                                    <div className='notfication-icon'>
                                                        <CiSettings className='notfication-icons' />

                                                    </div>
                                                </Col>

                                                <Col md={2}>
                                                    <div className='notfication-icon'>
                                                        <MdOutlineEmail className='notfication-icons' />
                                                        <span className='notification-number'>
                                                            <TbPointFilled />
                                                        </span>
                                                    </div>
                                                </Col>

                                                <Col md={2}>
                                                    <div className='notfication-icon'>
                                                        <IoMdNotificationsOutline className='notfication-icons' />
                                                        <span className='notification-number'>
                                                            <TbPointFilled />
                                                        </span>
                                                    </div>
                                                </Col>

                                                <Col md={2}>
                                                    <Dropdown className='user-dropdown-button'>
                                                        <Dropdown.Toggle id="dropdown-example1">
                                                            <FaUserCircle className='user-profile-icon' />
                                                        </Dropdown.Toggle>

                                                        <Dropdown.Menu>
                                                            <Dropdown.Item href="#/action-1">
                                                                User
                                                            </Dropdown.Item>
                                                            <Dropdown.Item href="#/action-2">Profile</Dropdown.Item>
                                                            <Dropdown.Item onClick={logoutfunctiom} >
                                                                Logout
                                                            </Dropdown.Item>

                                                        </Dropdown.Menu>
                                                    </Dropdown>
                                                </Col>
                                                {/* <Col md={4}></Col> */}
                                                {/* <Col md={2}></Col> */}
                                            </Row>

                                        </div>
                                    </Col>
                                </Row>
                            </header>
                        </Col>
                    </Row>
                    {/* <Header /> */}
                </Nav>
                {/* End -header */}


                {/* start-siebar */}
                <SidebarNav sidebar={sidebar}>
                    <SidebarWrap>
                        <NavIcon to="#">
                            <AiIcons.AiOutlineClose
                                onClick={showSidebar}
                            />
                        </NavIcon>
                        {SidebarData.map((item, index) => {
                            return (
                                <SubMenu
                                    item={item}
                                    key={index}
                                />
                            );
                        })}
                    </SidebarWrap>
                </SidebarNav>
                {/* End- siebar */}

            </IconContext.Provider>
        </>
    );
};

export default Sidebar;