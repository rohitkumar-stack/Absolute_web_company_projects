import React, { useEffect } from 'react'
import { Outlet, useNavigate } from 'react-router-dom';
import Sidebar from '../sidebar/Sidebar';

const ProtectedRoute = () => {
    const navigate = useNavigate()
    const StoredData = localStorage.getItem("authUser");
    useEffect(() => {
        if (!StoredData) {
            navigate('/login')
        }
    }, [])
    return (
        <React.Fragment>
            <Sidebar />
            <Outlet />
        </React.Fragment>
    )
}

export default ProtectedRoute