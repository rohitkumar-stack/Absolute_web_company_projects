// const BASE_URL = "https://absoluteweb.org/absmanagement/api/public/v1/";
// export const LOGIN = BASE_URL + 'tenantuser/login'
