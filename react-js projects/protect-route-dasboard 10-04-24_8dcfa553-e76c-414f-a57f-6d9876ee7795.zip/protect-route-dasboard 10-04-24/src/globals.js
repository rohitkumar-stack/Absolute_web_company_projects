
//API BASE URL
const BASE_URL = "https://absoluteweb.org/absmanagement/api/public/v1";

export const LOGIN_URL = `${BASE_URL}/tenantuser/login`;
export const RESET_PASSWORD_URL = `${BASE_URL}/resettenantuserpassword`;