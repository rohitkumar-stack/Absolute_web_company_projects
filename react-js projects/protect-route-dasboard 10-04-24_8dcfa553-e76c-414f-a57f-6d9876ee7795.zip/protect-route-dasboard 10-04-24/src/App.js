import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import ProtectedRoute from './components/protectedroute/ProtectedRoute';
import Dashboard from './pages/dashboard/Dashboard';
import Login from './pages/login/Login';
import ResetPassword from './pages/resetPassword/ResetPassword';
import ForgotPassword from './pages/forgotPassword/ForgotPassword';
import About from './pages/about/About';
import './App.css'

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route element={<ProtectedRoute />}>
      
                <Route
                    path="/dashboard"
                    element={<Dashboard />}
                />
                {/* <Route
                    path="/about-us/aim"
                    element={<OurAim />}
                />
                <Route
                    path="/about-us/vision"
                    element={<OurVision />}
                />
                <Route
                    path="/services"
                    element={<Services />}
                />
                <Route
                    path="/services/services1"
                    element={<ServicesOne />}
                />
                <Route
                    path="/services/services2"
                    element={<ServicesTwo />}
                />
                <Route
                    path="/services/services3"
                    element={<ServicesThree />}
                />
                <Route
                    path="/contact"
                    element={<Contact />}
                />
                <Route
                    path="/events"
                    element={<Events />}
                />
                <Route
                    path="/events/events1"
                    element={<EventsOne />}
                />
                <Route
                    path="/events/events2"
                    element={<EventsTwo />}
                />
                <Route
                    path="/support"
                    element={<Support />}
                /> */}
          </Route>
          <Route element={<Login />} path="/" />
          <Route element={<ResetPassword />} path="/ResetPassword" />
        </Routes>
      </Router>
    </div>
  );
}

export default App;