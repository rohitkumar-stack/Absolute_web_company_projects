import React, { Component } from "react";
import { Row, Col, Card, CardBody, Container, Label, Form, Button, FormGroup } from "reactstrap";
//Import Breadcrumb
import Breadcrumb from "../../../components/Common/Breadcrumb";
import { AvForm, AvField, AvRadioGroup, AvRadio, AvGroup, AvInput } from "availity-reactstrap-validation";
import PhoneInput from "react-phone-input-2";
import Dropzone from "react-dropzone";
import { Link } from "react-router-dom";
import 'react-phone-input-2/lib/style.css'
import { toast } from "react-toastify";
import { CREATE_USER, GET_COUNTRY, GET_COUNTRY_BY_ID, GET_CUSTOMER_BY_ID, GET_DEPARTMENT_BY_ID, GET_DESIGNATION_BY_ID, GET_HSN_CODE_BY_ID, GET_INDUSTRIAL_TYPE_BY_ID, GET_ITEM_CATEGORY, GET_ITEM_CATEGORY_BY_ID, GET_ITEM_MAKER_BY_ID, GET_ITEM_SUB_CATEGORY_BY_ID, GET_LEAD_REFERENCE_BY_ID, GET_LEAVE_BY_ID, GET_LEDGER_GROUP_BY_ID, GET_OWNERSHIP_WO_PAGINATE, GET_SHIFT_BY_ID, GET_STATE, GET_TERMS_CONDITIONS_BY_ID, GET_UNIT_BY_ID, GET_UNIT_MEASURE_BY_ID, GET_USER_BY_ID, GET_WAREHOUSE_BY_ID, UPDATE_COUNTRY, UPDATE_CUSTOMER, UPDATE_DEPARTMENT, UPDATE_DESIGNATION, UPDATE_HSN_CODE, UPDATE_INDUSTRIAL_TYPE, UPDATE_ITEM_CATEGORY, UPDATE_ITEM_MAKE, UPDATE_ITEM_SUB_CATEGORY, UPDATE_LEAD_REFERENCE, UPDATE_LEAVE, UPDATE_LEDGER_GROUP, UPDATE_SHIFT, UPDATE_TERMS_CONDITIONS, UPDATE_UNIT, UPDATE_UNIT_MEASURE, UPDATE_USER, UPDATE_WAREHOUSE } from "../../../globals";
import { ThreeDots } from "react-loader-spinner";

class EditCustomer extends Component {
    constructor(props) {
        super(props);
        this.state = {
            breadcrumbItems: [
                { title: "Customer", link: process.env.PUBLIC_URL + "/customerlist" },
                { title: "Edit Customer", link: process.env.PUBLIC_URL + "/#" },
            ],

            selectedFiles: [],
            getById: {},
            inputMobileField: "",
            isLoading: false,
            status: "",
            itemcategory: [],
            inputnumber: "",
            Statelist: [],
            countrylist: [],
            ownershiplist: [],

        };
        this.handleSubmit = this.handleSubmit.bind(this);
    };


    handleAcceptedFiles = (files) => {
        this.getBase64Icon(files);
        files.map((file) =>
            Object.assign(file, {
                preview: URL.createObjectURL(file),

            })
        );
        this.setState({ selectedFiles: files });
    };

    // GET ALL DESIGNATION GROUP
    async GetAllState() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_STATE, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ Statelist: data.data });
                    } else {

                    }
                });
            });
        } catch (error) {

        }
    }

    // GET ALL OWNERSHIP GROUP
    async GetAllOwnership() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_OWNERSHIP_WO_PAGINATE, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ ownershiplist: data.data });
                    } else {

                    }
                });
            });
        } catch (error) {

        }
    }

    // GET ALL DESIGNATION GROUP
    async GetAllCountry() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_COUNTRY, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ countrylist: data.data });
                    } else {

                    }
                });
            });
        } catch (error) {

        }
    }

    async getBase64Icon(files) {
        const file = files[0];
        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);

            reader.onload = () => {
                const base64Data = reader.result;
                let base64Split = base64Data.split(",");
                const Img = base64Split[1];
                this.setState({ Img: Img });
            };

            reader.onerror = (error) => {
                console.error("Error occurred while reading the file:", error);
            };
        }
    }

    componentDidMount() {
        this.GetAllOwnership();
        this.GetAllState();
        this.GetAllCountry();

        // Access the location object to get route parameters
        const { location } = this.props;
        const { pathname } = location;

        // Parse the pathname to get the id parameter
        const id = pathname.substring(pathname.lastIndexOf("/") + 1);
        // this.setState({ id: id })
        this.GetHSNCOde(id);
    }




    // GET 
    async GetHSNCOde(id) {
        this.setState({
            isLoading: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                GET_CUSTOMER_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                getById: data.data,
                                status: data.data.status,
                                inputnumber: data.data.office_phone_no
                            });
                            this.setState({
                                isLoading: false,
                            });
                        }
                    } else {

                        this.setState({
                            isLoading: false,
                        });
                    }
                });
            });
        } catch (error) {
            this.setState({
                isLoading: false,
            });

            this.setState({
                isLoading: false,
            });
        }
    }

    handleSubmit(event, values) {
        this.setState({
            isLoading: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(UPDATE_CUSTOMER + this.state.getById.id, {
                method: "POST",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    company_name: values.companyname,
                    address: values.address,
                    city: values.city,
                    state_id_encode: values.state,
                    country_id_encode: values.country,
                    pincode: values.pincode,
                    office_phone_no: this.state.inputnumber,
                    customer_category: values.category,
                    customer_type: values.type,
                    ownership_type_id_encode: values.ownership,
                    status: "Active"
                }),
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.props.history.goBack();
                        toast("Customer Updated Successfully !", {
                            type: "success",
                        });
                        this.setState({
                            isLoading: false
                        });
                    } else {
                        toast("Unable to Update Customer", {
                            type: "error",
                        });
                        toast(data.message, {
                            type: "error",
                        });
                        this.setState({
                            isLoading: false,
                        });
                    }
                });
            });
        } catch (error) {
            toast("Unable to Update Customer", {
                type: "error",
            });
            this.setState({
                isLoading: false,
            });

        }
    }

    render() {
        return (
            <React.Fragment>
                <div className="page-content">
                    <Container fluid>
                        <Breadcrumb title="Edit Customer" breadcrumbItems={this.state.breadcrumbItems} />
                        {this.state.isLoading ? (
                            <>
                                <ThreeDots
                                    height="80"
                                    width="80"
                                    radius="9"
                                    color="#4D5DC6"
                                    ariaLabel="three-dots-loading"
                                    wrapperStyle={{
                                        justifyContent: "center",
                                    }}
                                    wrapperClassName=""
                                    visible={true}
                                />
                            </>
                        ) : (
                            <Card>
                                <CardBody>

                                    <AvForm
                                        className="needs-validation"
                                        onValidSubmit={this.handleSubmit}
                                    // onSubmit={this.submitStep1}
                                    >
                                        <Row className="mt-2">
                                            <Col lg="3">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom01"
                                                >
                                                    Company Name
                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                </Label>
                                                <AvField
                                                    value={this.state.getById.company_name}
                                                    name="companyname"
                                                    placeholder="Company Name"
                                                    type="text"
                                                    errorMessage="Please Provide Company Name"
                                                    className="form-control"
                                                    validate={{ required: { value: true } }}
                                                    id="validationCustom01"
                                                />
                                            </Col>
                                            <Col md="3" className="d-inline">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom02"
                                                >
                                                    Select Ownership
                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                </Label>
                                                <AvField
                                                    value={this.state.getById.ownership_type_id}
                                                    required={true}
                                                    name="ownership"
                                                    type="select"
                                                    id="validationCustom02"
                                                    // value={this.state.selectedcountry}
                                                    errorMessage="Please Select an Ownership."
                                                    validate={{ required: { value: true } }}
                                                    className="form-control"

                                                >
                                                    <option value={""} >Select Ownership</option>
                                                    {this.state.ownershiplist.map((item) => {
                                                        return (
                                                            <option value={item.id}>{item.name}</option>

                                                        );
                                                    })}
                                                </AvField>
                                            </Col>
                                            <Col lg="3">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom01"
                                                >
                                                    City
                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                </Label>
                                                <AvField
                                                    value={this.state.getById.city}
                                                    name="city"
                                                    placeholder="City"
                                                    type="text"
                                                    errorMessage="Please Provide City"
                                                    className="form-control"
                                                    validate={{ required: { value: true } }}
                                                    id="validationCustom01"
                                                />
                                            </Col>
                                            <Col md="3" className="d-inline">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom02"
                                                >
                                                    Select State
                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                </Label>
                                                <AvField
                                                    value={this.state.getById.state_id}
                                                    required={true}
                                                    name="state"
                                                    type="select"
                                                    id="validationCustom02"
                                                    // value={this.state.selectedcountry}
                                                    errorMessage="Please Select a State."
                                                    validate={{ required: { value: true } }}
                                                    className="form-control"

                                                >
                                                    <option value={""} >Select State</option>
                                                    {this.state.Statelist.map((item) => {
                                                        return (
                                                            <option value={item.id}>{item.state_name}</option>

                                                        );
                                                    })}
                                                </AvField>
                                            </Col>
                                            <Col md="3" className="d-inline">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom04"
                                                >
                                                    Select Country
                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                </Label>
                                                <AvField
                                                    value={this.state.getById.country_id}
                                                    required={true}
                                                    name="country"
                                                    type="select"
                                                    id="validationCustom04"
                                                    // value={this.state.selectedcountry}
                                                    errorMessage="Please Select a Country."
                                                    validate={{ required: { value: true } }}
                                                    className="form-control"
                                                    onChange={(e) => {
                                                        this.setState({
                                                            selectedcountry: e.target.value,
                                                        });
                                                    }}
                                                >
                                                    <option value={""} >Select Country</option>
                                                    {this.state.countrylist.map((item) => {
                                                        return (
                                                            <option value={item.id}>{item.country_name}</option>

                                                        );
                                                    })}
                                                </AvField>
                                            </Col>
                                            <Col lg="3">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom08"
                                                >
                                                    Pincode
                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                </Label>
                                                <AvField
                                                    value={this.state.getById.pincode}
                                                    name="pincode"
                                                    placeholder="Pincode"
                                                    type="number"
                                                    errorMessage="Please Provide Pincode"
                                                    className="form-control"
                                                    validate={{
                                                        required: { value: true },
                                                        maxLength: {
                                                            value: 6,
                                                            errorMessage:
                                                                "Pincode cannot exceed 6 characters",
                                                        },
                                                    }}
                                                    // validate={{ required: { value: true } }}
                                                    id="validationCustom08"
                                                />
                                            </Col>
                                            <Col md="3">
                                                <div className="mb-3">
                                                    <Label
                                                        className="form-label"
                                                        htmlFor="validationCustom007"
                                                    >
                                                        Office Phone No.
                                                        <span style={{ color: "#ff0000" }}>*</span>
                                                    </Label>


                                                    <PhoneInput
                                                        value={this.state.inputnumber}
                                                        placeholder=""
                                                        country={"in"}
                                                        enableSearch={true}
                                                        errorMessage=" Please provide a Number"
                                                        id="validationCustom007"
                                                        validate={{
                                                            required: {
                                                                value: true
                                                            },
                                                        }}
                                                        inputStyle={{ width: "100%" }}
                                                        style={{
                                                            borderRadius: 50,
                                                        }}
                                                        inputProps={{
                                                            name: 'mobile',
                                                            required: true,

                                                        }}
                                                        onChange={(phone) => {
                                                            this.setState({
                                                                inputnumber: phone,
                                                            });

                                                        }}
                                                    />
                                                </div>
                                            </Col>
                                            <Col lg="3">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom01"
                                                >
                                                    Customer Category
                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                </Label>
                                                <AvField
                                                    value={this.state.getById.customer_category}
                                                    name="category"
                                                    placeholder="Customer Category"
                                                    type="select"
                                                    errorMessage="Please Provide Customer Category"
                                                    className="form-control"
                                                    validate={{ required: { value: true } }}
                                                    id="validationCustom01"
                                                >
                                                    <option value={"Customer Category 1"} >Customer Category 1</option>
                                                    <option value={"Customer Category 2"} >Customer Category 2</option>
                                                    <option value={"Customer Category 3"} >Customer Category 3</option>
                                                </AvField>
                                            </Col>
                                            <Col lg="3">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom01"
                                                >
                                                    Customer Type
                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                </Label>
                                                <AvField
                                                    value={this.state.getById.customer_type}
                                                    name="type"
                                                    placeholder="Customer Type"
                                                    type="select"
                                                    errorMessage="Please Provide Customer Type"
                                                    className="form-control"
                                                    validate={{ required: { value: true } }}
                                                    id="validationCustom01"
                                                >
                                                    <option value={"Customer Type 1"} >Customer Type 1</option>
                                                    <option value={"Customer Type 2"} >Customer Type 2</option>
                                                    <option value={"Customer Type 3"} >Customer Type 3</option>
                                                </AvField>
                                            </Col>
                                            <Col lg="3">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom01"
                                                >
                                                    Address
                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                </Label>
                                                <AvField
                                                    value={this.state.getById.address}
                                                    name="address"
                                                    placeholder="Address"
                                                    type="textarea"
                                                    errorMessage="Please Provide Address"
                                                    className="form-control"
                                                    validate={{ required: { value: true } }}
                                                    id="validationCustom01"
                                                />
                                            </Col>
                                            {/* <Col lg="3">
                                            <Label
                                                className="form-label"
                                                htmlFor="validationCustom01"
                                            >
                                                Warehouse Location
                                                <span style={{ color: "#ff0000" }}>*</span>
                                            </Label>
                                            <AvField
                                                name="location"
                                                placeholder="Warehouse Location"
                                                type="text"
                                                errorMessage="Please Provide Warehouse Location"
                                                className="form-control"
                                                validate={{ required: { value: true } }}
                                                id="validationCustom01"
                                            />
                                        </Col> */}
                                            {/* <Col md="4">
                                            <div className="mb-3">
                                                <Label
                                                    className="form-label"
                                                    htmlFor="validationCustom04"
                                                >
                                                    Status
                                                </Label>
                                                <br></br>
                                                <input
                                                    checked={this.state.status == "Active" ? true : false}
                                                    // checked={
                                                    //     this.state.isWhatsapp === "1" ? true : false
                                                    // }
                                                    onChange={(val) =>
                                                        this.setState({
                                                            status: val.target.checked ? "Active" : "",
                                                        })
                                                    }
                                                    className="form-check-input"
                                                    type="checkbox"

                                                    id="invalidCheck3"
                                                    required={true}
                                                />
                                                <label
                                                    className="form-check-label px-2"
                                                    htmlFor="invalidCheck3"
                                                >
                                                    Active
                                                </label>
                                                <div className="invalid-feedback">
                                                    Select Active
                                                </div>
                                            </div>
                                        </Col> */}
                                        </Row>

                                        <Button color="primary" type="submit" >
                                            Update
                                        </Button>

                                        <Button
                                            color="secondary"
                                            className="mx-2"
                                            onClick={() => this.props.history.goBack()}
                                        >
                                            Cancel
                                        </Button>
                                    </AvForm>
                                </CardBody>
                            </Card>
                        )}
                    </Container>
                </div>
            </React.Fragment >
        );
    };
};

export default EditCustomer;
