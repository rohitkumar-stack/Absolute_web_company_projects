import React, { Component } from "react";

// MetisMenu
import MetisMenu from "metismenujs";
import { withRouter } from "react-router-dom";
import { Link } from "react-router-dom";

//i18n
import { withNamespaces } from 'react-i18next';

import { connect } from "react-redux";
import {
    changeLayout,
    changeLayoutWidth,
    changeSidebarTheme,
    changeSidebarType,
    changePreloader
} from "../../store/actions";
import { GET_ALL_PERMISSIONS, GET_PERMISSIONS_BY_ID, GET_USER_BY_ID, THEME_SETTING } from "../../globals";

class SidebarContent extends Component {

    constructor(props) {
        super(props);
        this.state = {
            allpermissions: [],
            userpermission: [],
            ShowLeaveModule: false
        };

        this.sidebarArr = [
            {
                href: "hsncodelist",
                value: "hsn_code",
                label: "HSN Code"
            },
            {
                href: "countrylist",
                value: "country",
                label: "Country"
            },
            {
                href: "statelist",
                value: "state",
                label: "State"
            },
            {
                href: "ledgerlist",
                value: "ledger",
                label: "Ledger"
            },
            {
                href: "ledgergrouplist",
                value: "ledger_group",
                label: "Ledger Group"
            },
            {
                href: "termsandconditionslist",
                value: "terms_condition",
                label: "Terms & Conditions"
            },
            {
                href: "departmentlist",
                value: "department",
                label: "Department"
            },
            {
                href: "designationlist",
                value: "designation",
                label: "Designation"
            },
            {
                href: "itemcategorylist",
                value: "item_category",
                label: "Item Category"
            },
            {
                href: "itemsubcategorylist",
                value: "item_sub_category",
                label: "Item Sub-Category"
            },
            {
                href: "itemmakelist",
                value: "item_make",
                label: "Item Make"
            },
            {
                href: "itemlist",
                value: "item",
                label: "Item"
            },
            {
                href: "shiftlist",
                value: "shift",
                label: "Shift"
            },
            {
                href: "unitlist",
                value: "unit",
                label: "Unit"
            },
            {
                href: "unitmeasurelist",
                value: "unit_measure",
                label: "Unit Measure"
            },
            {
                href: "warehouselist",
                value: "warehouse",
                label: "Warehouse"
            },
            {
                href: "leavelist",
                value: "leave",
                label: "Leave"
            },
            {
                href: "leavebalancelist",
                value: "leave_balances",
                label: "Leave Balance"
            },
            {
                href: "leaverequestlist",
                value: "leave_request",
                label: "Leave Request"
            },

        ]
    }

    async componentDidMount() {
        this.loadPermissions();
        this.getUserPermissions();
        this.initMenu();
        this.GetThemesetting();
    }

    // GET USER
    async GetThemesetting() {
        this.setState({
            isLoading: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                THEME_SETTING,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.GetUserByID(data.data[0].employee_leave_allow_afterdays)
                            this.setState({
                                isLoading: false,
                            });
                        }
                    } else {
                        this.setState({
                            isLoading: false,
                        });
                    }
                });
            });
        } catch (error) {
            this.setState({
                isLoading: false,
            });
        }
    }

    // GET USER
    async GetUserByID(Days) {
        let id = localStorage.getItem("tenant_id")
        this.setState({
            isLoading: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                GET_USER_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            const endDate = new Date(data.data.end_dt);
                            const today = new Date();
                            const countedtotaldays = new Date(endDate.setDate(endDate.getDate() + parseInt(Days)));
                            if (countedtotaldays < today) {
                                this.setState({ ShowLeaveModule: true });
                            } else if (data.data.end_dt === "" && data.data.employee_status === "2") {
                                this.setState({ ShowLeaveModule: true });
                            } else {
                                this.setState({ ShowLeaveModule: false });
                            }
                        }
                    }
                });
            });
        } catch (error) {
        }
    }

    // TO SHOW USER WHAT PERMISSION ARE  INTO SHOW MODAL
    async loadPermissions() {
        const PermissionArr = await JSON.parse(localStorage.getItem("permissionarray"));
        let tempArr = [];
        PermissionArr?.map((item) => {
            this.sidebarArr.map((sidebar) => {
                if (item.name.includes("Show") && (item.type === sidebar.value)) {
                    tempArr.push({
                        lebel: sidebar.label,
                        value: sidebar.href,
                        active: item.status,
                    });
                }
            });
        });
        this.setState({ finalLI: tempArr })
    }

    // FETCH USER PERMISSIONS
    async getUserPermissions() {
        this.setState({
            isLoading: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                // GET_PERMISSIONS,
                GET_ALL_PERMISSIONS,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ allpermissions: data.data })
                        // this.setState({ tempAll: data.data })
                        this.getAllUserPermissions(data.data)
                    } else {
                        this.setState({
                            isLoading: false,
                        });
                    }
                });
            });
        } catch (error) {

            this.setState({
                isLoading: false,
            });
        }
    }

    // FETCH ALL USER ROLE  PERMISSIONS
    async getAllUserPermissions(allpermissions) {
        this.setState({
            isLoading: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                // GET_PERMISSIONS,
                GET_PERMISSIONS_BY_ID + this.state.id,
                // GET_ALL_PERMISSIONS,
                {
                    method: "POST",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    this.setState({ userpermission: data.data })
                    // if (data.result === true) {
                    //     if (data.data) {
                    let userpermission = data.data || [];
                    let finalarr = [];
                    var flag = false;
                    allpermissions.map((allpermissions) => {
                        flag = false;
                        userpermission.map((userpermissions) => {
                            if (allpermissions.id === userpermissions.permission_id) {
                                flag = false;
                                finalarr.push({ ...userpermissions, type: allpermissions.type, update_id: allpermissions.id })
                                flag = true;
                            }

                        })

                        if (!flag) {
                            finalarr.push({ ...allpermissions, status: "Inactive", update_id: allpermissions.id })
                        }
                    })

                    let tempArr = [];
                    finalarr?.map((item) => {
                        this.sidebarArr.map((sidebar) => {
                            if (item.name.includes("Add") && (item.type === sidebar.value)) {
                                tempArr.push({
                                    lebel: sidebar.label,
                                    value: sidebar.href,
                                    active: item.status
                                })
                            }
                        })
                    })
                });
            });
        } catch (error) {

            this.setState({
                isLoading: false,
            });
        }
    }


    componentDidUpdate(prevProps) {
        if (prevProps !== this.props) {
            if (this.props.type !== prevProps.type) {
                this.initMenu();
            }

        }
    }

    initMenu() {
        new MetisMenu("#side-menu");

        var matchingMenuItem = null;
        var ul = document.getElementById("side-menu");
        var items = ul.getElementsByTagName("a");
        for (var i = 0; i < items.length; ++i) {
            if (this.props.location.pathname === items[i].pathname) {
                matchingMenuItem = items[i];
                break;
            }
        }
        if (matchingMenuItem) {
            this.activateParentDropdown(matchingMenuItem);
        }
    }

    activateParentDropdown = item => {
        item.classList.add("active");
        const parent = item.parentElement;

        if (parent) {
            parent.classList.add("mm-active");
            const parent2 = parent.parentElement;

            if (parent2) {
                parent2.classList.add("mm-show");

                const parent3 = parent2.parentElement;

                if (parent3) {
                    parent3.classList.add("mm-active"); // li
                    parent3.childNodes[0].classList.add("mm-active"); //a
                    const parent4 = parent3.parentElement;
                    if (parent4) {
                        parent4.classList.add("mm-active");
                    }
                }
            }
            return false;
        }
        return false;
    };

    toggleDropdown = () => {
        this.setState((prevState) => ({
            isDropdownOpen: !prevState.isDropdownOpen,
        }));
    }


    render() {
        const { isDropdownOpen, ShowLeaveModule } = this.state;
        const Roleid = localStorage.getItem("roleid");
        // const EmploymentStatus = parseInt(localStorage.getItem("employmentstatus"));
        return (
            <React.Fragment>

                {/* ADMIN  */}
                {Roleid === "NxOpZowo9GmjKqdR" && (
                    <div id="sidebar-menu">
                        <ul className="metismenu list-unstyled" id="side-menu" >
                            <li>
                                <Link to={process.env.PUBLIC_URL + "/dashboard"} className="waves-effect">
                                    <i className="ri-dashboard-fill"></i>
                                    <span className="ms-1">{this.props.t('Dashboard')}</span>
                                </Link>
                            </li>
                            {this.state.finalLI != [] && (
                                <li >
                                    <Link to="/#" className="has-arrow waves-effect ">
                                        <i className="ri ri-settings-2-fill "></i>

                                        <span className="ms-1">{this.props.t('Masters')}</span>
                                    </Link>
                                    <ul className="sub-menu">
                                        <li >

                                            <Link to={process.env.PUBLIC_URL + "/roleslist"}>

                                                <span> {this.props.t('Roles')}</span>
                                            </Link>
                                        </li>
                                        {this.state.finalLI?.map((item) => {
                                            return (
                                                <li>
                                                    <Link to={process.env.PUBLIC_URL + `/${item.value}`}>
                                                        <span > {this.props.t(`${item.lebel}`)}</span>
                                                    </Link>
                                                </li>
                                            )
                                        })}
                                        <li>
                                            <Link to={process.env.PUBLIC_URL + "/leaveentitlementlist"}>
                                                <span> {this.props.t('Leave Entitlement')}</span>
                                            </Link>
                                        </li>
                                        <li>
                                            <Link to={process.env.PUBLIC_URL + "/leadreferencelist"}>
                                                <span> {this.props.t('Lead Reference')}</span>
                                            </Link>
                                        </li>
                                        <li>
                                            <Link to={process.env.PUBLIC_URL + "/industrialtypelist"}>
                                                <span> {this.props.t('Industrial Type')}</span>
                                            </Link>
                                        </li>
                                        <li>
                                            <Link to={process.env.PUBLIC_URL + "/ownershiplist"}>
                                                <span> {this.props.t('Ownership')}</span>
                                            </Link>
                                        </li>
                                        <li>
                                            <Link to={process.env.PUBLIC_URL + "/contactpersonlist"}>
                                                <span> {this.props.t('Contact Person')}</span>
                                            </Link>
                                        </li>
                                        <li>
                                            <Link to={process.env.PUBLIC_URL + "/customerlist"}>
                                                <span> {this.props.t('Customers')}</span>
                                            </Link>
                                        </li>


                                    </ul>
                                </li>
                            )}

                            <li>
                                <Link to={process.env.PUBLIC_URL + "/users"}>
                                    <i className="fas fa-user-friends" style={{ paddingRight: "5px" }}></i>
                                    <span > {this.props.t('Users')}</span>
                                </Link>
                            </li>
                            <li >
                                <Link to={process.env.PUBLIC_URL + "/marketingleadlist"}>
                                    <i className="ri ri-file-edit-line" style={{ paddingRight: "5px" }}></i>
                                    <span> {this.props.t('Marketing Lead')}</span>
                                </Link>
                            </li>
                            <li>
                                <Link to={process.env.PUBLIC_URL + "/themesetting"}>
                                    <i className="ri ri-palette-line" style={{ paddingRight: "5px" }}></i>
                                    <span > {this.props.t('Theme Setting')}</span>
                                </Link>
                            </li>
                        </ul>
                    </div>
                )}

                {/* OTHER ROLES */}
                {/* IF NOT ADMIN THEN THIS DASHBOARD WILL BE SHOWN  */}

                {Roleid != "NxOpZowo9GmjKqdR" && (
                    <div id="sidebar-menu">
                        <ul className="metismenu list-unstyled" id="side-menu">
                            <li >
                                <Link to={process.env.PUBLIC_URL + "/dashboard"} className="waves-effect">
                                    <i className="ri-dashboard-fill"></i>
                                    <span className="ms-1">{this.props.t('Dashboard')}</span>
                                </Link>
                            </li>
                            {this.state.finalLI && this.state.finalLI.length > 0 && this.state.finalLI.filter(item => item.active === "Active").length > 0 && (
                                <li >
                                    {/* <Link to="#" className="has-arrow waves-effect "> */}
                                    <Link to="#" className={`nav-link dropdown-toggle has-arrow waves-effect`}>
                                        <i className="ri ri-settings-2-fill "></i>
                                        <span className="ms-1">{this.props.t('Masters')}</span>
                                    </Link>
                                    {/* <ul className="sub-menu" > */}
                                    <ul className={`sub-menu ${isDropdownOpen ? 'show' : ''}`}>

                                        {this.state.finalLI.map((item) => {

                                            if (item.active === "Active") {
                                                return (
                                                    <li>
                                                        <Link to={process.env.PUBLIC_URL + `/${item.value}`} >
                                                            <span className="ms-1">{this.props.t(`${item.lebel}`)}</span>
                                                        </Link>
                                                    </li>
                                                )
                                            }
                                        })}
                                    </ul>
                                </li>
                            )}

                            {ShowLeaveModule == true && (
                                <li>
                                    <Link to={process.env.PUBLIC_URL + "/employeeleavelist"} className="waves-effect">
                                        <i className=" ri-calendar-todo-fill "></i>
                                        <span className="ms-1">{this.props.t('Leave')}</span>
                                    </Link>
                                </li>
                            )}
                            {Roleid === "0QvXO3GJyzkxAqYR" && (
                                <>
                                    < li >
                                        <Link to={process.env.PUBLIC_URL + `/employeeleaves`}>
                                            <i className=" ri-calendar-check-fill "></i>
                                            <span className="ms-1">{this.props.t(`Employee Leaves`)}</span>
                                        </Link>
                                    </li>
                                    <li>
                                        <Link to={process.env.PUBLIC_URL + "/users"}>
                                            <i className="fas fa-user-friends" style={{ paddingRight: "5px" }}></i>
                                            <span > {this.props.t('Users')}</span>
                                        </Link>
                                    </li>
                                </>
                            )}
                        </ul>
                    </div>
                )
                }
            </React.Fragment>
        );
    }
}

const mapStatetoProps = state => {
    return { ...state.Layout };
};

export default withRouter(connect(mapStatetoProps, {
    changeLayout,
    changeSidebarTheme,
    changeSidebarType,
    changeLayoutWidth,
    changePreloader
})(withNamespaces()(SidebarContent)));
