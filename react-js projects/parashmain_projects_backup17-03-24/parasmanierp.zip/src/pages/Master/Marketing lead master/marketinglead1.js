import React, { Component } from "react";
import { Row, Col, Card, CardBody, Container, Label, Form, Button, FormGroup, CardHeader, Input, Table, Modal, ModalHeader, ModalBody, NavItem, NavLink, TabContent, TabPane, Collapse, CardImg } from "reactstrap";
//Import Breadcrumb
import Breadcrumb from "../../../components/Common/Breadcrumb";
import { AvForm, AvField, AvRadioGroup, AvRadio, AvGroup, AvInput } from "availity-reactstrap-validation";
import PhoneInput from "react-phone-input-2";
import Dropzone from "react-dropzone";
import { Link } from "react-router-dom";
import 'react-phone-input-2/lib/style.css'
import { toast } from "react-toastify";
import { CREATE_LEAD_ACTIVITY, CREATE_LEAD_COMMENT, CREATE_USER, GET_ALL_CUSTOMER_WO_PAGINATION, GET_CONTACTPERSON_BY_ID, GET_CONTACTPERSON_WO_PAGINATE, GET_COUNTRY, GET_COUNTRY_BY_ID, GET_CUSTOMER_BY_ID, GET_DEPARTMENT_BY_ID, GET_DESIGNATION_BY_ID, GET_HSN_CODE_BY_ID, GET_ITEM_CATEGORY, GET_ITEM_CATEGORY_BY_ID, GET_ITEM_MAKER_BY_ID, GET_ITEM_SUB_CATEGORY_BY_ID, GET_LEAD_ACTIVITY_BY_ID, GET_LEAD_COMMENTS_BY_ID, GET_LEAD_LOG_BY_ID, GET_LEAD_REFERENCE_BY_ID, GET_LEAD_REFERENCE_WO_PAGINATE, GET_LEAVE_BY_ID, GET_LEDGER_GROUP_BY_ID, GET_MARKETING_LEAD_BY_ID, GET_MARKETING_LEAD_DOCUMENT_BY_ID, GET_OWNERSHIP_BY_ID, GET_OWNERSHIP_WO_PAGINATE, GET_SHIFT_BY_ID, GET_TERMS_CONDITIONS_BY_ID, GET_UNIT_BY_ID, GET_UNIT_MEASURE_BY_ID, GET_USER_BY_ID, GET_WAREHOUSE_BY_ID, UPDATE_COUNTRY, UPDATE_DEPARTMENT, UPDATE_DESIGNATION, UPDATE_DOCUMENT_LEAD, UPDATE_HSN_CODE, UPDATE_ITEM_CATEGORY, UPDATE_ITEM_MAKE, UPDATE_ITEM_SUB_CATEGORY, UPDATE_LEAD_MARKETING, UPDATE_LEAD_REFERENCE, UPDATE_LEAVE, UPDATE_LEDGER_GROUP, UPDATE_OWNERSHIP, UPDATE_SHIFT, UPDATE_TERMS_CONDITIONS, UPDATE_UNIT, UPDATE_UNIT_MEASURE, UPDATE_USER, UPDATE_WAREHOUSE } from "../../../globals";
import { ThreeDots } from "react-loader-spinner";
import CustomFileInputNew from "../../../components/Common/imagefunction";
import Nav from 'react-bootstrap/Nav';
import img2 from "../../../assets/images/small/img-2.jpg";
import img3 from "../../../assets/images/small/img-3.jpg";
import img4 from "../../../assets/images/small/img-4.jpg";
import classnames from "classnames";
import avatar3 from "../../../assets/images/users/avatar-3.jpg";
import avatar4 from "../../../assets/images/users/avatar-4.jpg";
import SimpleBar from "simplebar-react";
import { ImEye } from "react-icons/im";
import NameCard from "./viewLeadComponents/NameCard";
import CardComp from "./viewLeadComponents/cardcomponent";

class ViewMarketLead1 extends Component {
    constructor(props) {
        super(props);
        this.state = {
            breadcrumbItems: [
                { title: "Marketing Lead", link: process.env.PUBLIC_URL + "/marketingleadlist" },
                { title: "Lead Dashboard", link: process.env.PUBLIC_URL + "/#" },
            ],
            OpenTextArea: false,
            isLoading1: false,
            selectedFiles: [],
            getById: {},
            Paramdata: [],
            inputMobileField: "",
            isLoading: false,
            status: "",
            itemcategory: [],
            Leadreferencelist: [],
            customerlist: [],
            selectedlead: "",
            LeadDescription: "",
            Companydescription: "",
            selectedCopmany: "",
            ownershiplist: [],
            contactpersonlist: [],
            selectedcontactperson: "",
            ContactPersonDescription: "",
            leadDocument: "",
            currentStep: "1",
            ShowModal: false,
            modal_xlarge: false,
            ActivityModal: false,
            displayedComments: 5,
            LeadComments: [],
            LeadLogs: [],
            displayedCommentsforHistory: 5,

            historylistingloader: false,
            LeadHistoryTabledata: [],

            displayedLeadHistory: 5,
            Cardloading: false,
            LeadActivity: [],
            leadactivitylistingloader: false,
            LeadActivityDisplay: 5,
            // PROFILE IMAGE 
            defaultfile: "",
            fileData: "",
            selectedStartDate: null,
        };
        this.handleLeadActivity = this.handleLeadActivity.bind(this);
        this.handleLeadComments = this.handleLeadComments.bind(this);
        this.tog_xlarge = this.tog_xlarge.bind(this);
        this.ActivityModal = this.ActivityModal.bind(this);
        this.t_col1 = this.t_col1.bind(this);
        this.t_col2 = this.t_col2.bind(this);
        this.t_col3 = this.t_col3.bind(this);
        this.t_col5 = this.t_col5.bind(this);
    };


    handleAcceptedFiles = (files) => {
        this.getBase64Icon(files);
        files.map((file) =>
            Object.assign(file, {
                preview: URL.createObjectURL(file),

            })
        );
        this.setState({ selectedFiles: files });
    };

    async getBase64Icon(files) {
        const file = files[0];
        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);

            reader.onload = () => {
                const base64Data = reader.result;
                let base64Split = base64Data.split(",");
                const Img = base64Split[1];
                this.setState({ Img: Img });
            };

            reader.onerror = (error) => {
                console.error("Error occurred while reading the file:", error);
            };
        }
    }

    componentDidMount() {
        this.GetAllReferenceId();
        this.getAllCustomers();
        // Access the location object to get route parameters
        const { location } = this.props;
        const { pathname } = location;

        // Parse the pathname to get the id parameter
        const id = pathname.substring(pathname.lastIndexOf("/") + 1);
        // this.setState({ id: id })
        this.GetHSNCOde(id);
        this.LeadComments(id);
        this.LeadHistoryByID(id);
        this.LeadActivityByID(id);
        this.GetAllReferenceId();
        this.getAllCustomers();
        this.getAllContacts();

    }

    // GET LEAD COMMENTS
    async LeadComments(id) {
        this.setState({
            isLoading: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                GET_LEAD_COMMENTS_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                LeadComments: data.data,
                            });
                            this.setState({
                                isLoading: false,
                            });
                        }
                    } else {

                        this.setState({
                            isLoading: false,
                        });
                    }
                });
            });
        } catch (error) {
            this.setState({
                isLoading: false,
            });

            this.setState({
                isLoading: false,
            });
        }
    }

    // GET LEAD HISTORY
    async LeadHistoryByID(id) {
        this.setState({
            isLoading: true,
            historylistingloader: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                GET_LEAD_LOG_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                LeadLogs: data.data,
                                LeadHistoryTabledata: data.data
                            });
                            this.setState({
                                isLoading: false,
                                historylistingloader: false,
                            });
                        }
                    } else {
                        this.setState({
                            isLoading: false,
                            historylistingloader: false,
                        });
                    }
                });
            });
        } catch (error) {
            this.setState({
                isLoading: false,
                historylistingloader: false,
            });

            this.setState({
                isLoading: false,
                historylistingloader: false,
            });
        }
    }
    // GET LEAD ACTIVITY
    async LeadActivityByID(id) {
        this.setState({
            isLoading: true,
            leadactivitylistingloader: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                GET_LEAD_ACTIVITY_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                LeadActivity: data.data,
                                // leadactivitylistingloader: data.data
                                leadactivitylistingloader: false,
                            });
                        }
                    } else {
                        this.setState({
                            isLoading: false,
                            leadactivitylistingloader: false,
                        });
                    }
                });
            });
        } catch (error) {
            this.setState({
                isLoading: false,
                leadactivitylistingloader: false,
            });

            this.setState({
                isLoading: false,
                leadactivitylistingloader: false,
            });
        }
    }

    // Add a state variable to keep track of the number of comments to display
    loadMoreComments = () => {
        this.setState((prevState) => ({
            displayedComments: prevState.displayedComments + 10,
        }));
    };
    // Add a state variable to keep track of the number of comments to display
    loadMoreCommentsforhistory = () => {
        this.setState((prevState) => ({
            displayedCommentsforHistory: prevState.displayedCommentsforHistory + 10,
        }));
    };
    handleLoadMore = () => {
        this.setState((prevState) => ({
            LeadActivityDisplay: prevState.LeadActivityDisplay + 10,
        }));
    };

    loadMoreLeadHistory = () => {
        this.setState((prevState) => ({
            displayedLeadHistory: prevState.displayedLeadHistory + 5,
        }));
    };

    getTimeAgo(created_at) {
        const currentTime = new Date();
        const createdAt = new Date(created_at);

        const timeDifference = currentTime - createdAt;
        const seconds = Math.floor(timeDifference / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);

        if (hours > 0) {
            const remainingMinutes = minutes % 60;
            if (remainingMinutes > 0) {
                return `${hours}h ${remainingMinutes}mins ago`;
            } else {
                return `${hours}h ago`;
            }
        } else if (minutes > 0) {
            return `${minutes}mins ago`;
        } else {
            return `${seconds}secs ago`;
        }
    }


    // Callback function to handle file data
    handleFileDataChange = (file) => {
        this.setState({ fileData: file });
    };

    handleAadharBase64DataChange = (base64) => {
        this.setState({ defaultfile: base64 });
    };

    // GET ALL SENDERS
    async GetAllReferenceId() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_LEAD_REFERENCE_WO_PAGINATE, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ Leadreferencelist: data.data });
                    }
                    else if (data.result === false) {
                        toast(data.message, {
                            type: "error",
                        });
                    }
                    else {

                    }
                });
            });
        } catch (error) {

        }
    }

    // GET ALL SENDERS
    async getAllContacts() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_CONTACTPERSON_WO_PAGINATE, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ contactpersonlist: data.data });
                    }
                    else if (data.result === false) {
                        toast(data.message, {
                            type: "error",
                        });
                    }
                    else {

                    }
                });
            });
        } catch (error) {

        }
    }

    // GET ALL SENDERS
    async getAllCustomers() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_ALL_CUSTOMER_WO_PAGINATION, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ customerlist: data.data });
                    }
                    else if (data.result === false) {
                        toast(data.message, {
                            type: "error",
                        });
                    }
                    else {

                    }
                });
            });
        } catch (error) {

        }
    }

    // GET 
    async GetHSNCOde(id) {
        this.GetLeadDocument(id);
        this.setState({
            isLoading: true,
            Cardloading: true,
            isLoading1: true,
        });
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                GET_MARKETING_LEAD_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then(async (data) => {
                    if (data.result === true) {
                        if (data.data) {
                            await this.SearchLeadById(data.data?.lead_reference_id);
                            await this.SearchCompanyById(data.data?.customer_id);
                            await this.SearchContactPersonById(data.data?.contact_person_id_encode);
                            this.setState({
                                getById: data?.data,
                                Paramdata: data?.data,
                                inputnumber: data.data.mobile_no_1,
                                selectedlead: data.data?.lead_reference_id,
                                selectedCopmany: data.data?.customer_id,
                                selectedcontactperson: data.data?.contact_person_id_encode,
                                status: data.data.status,

                            });


                            this.setState({
                                isLoading: false,
                                Cardloading: false,
                                isLoading1: false,
                            });
                        }
                    } else {

                        this.setState({
                            isLoading: false,
                            Cardloading: false,
                            isLoading1: false,
                        });
                    }
                });
            });
        } catch (error) {
            this.setState({
                isLoading: false,
                Cardloading: false,
                isLoading1: false,
            });

            this.setState({
                isLoading: false,
                Cardloading: false,
                isLoading1: false,
            });
        }
    }

    // GET DETAILS BY ID 
    async GetLeadDocument(LeadID) {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_MARKETING_LEAD_DOCUMENT_BY_ID + LeadID, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({
                            leadDocument: data.data,
                            defaultfile: data.data.document_url
                        })
                    }
                });
            });
        } catch (error) {
            toast("Unable to Fetch Marketing Document", {
                type: "error",
            });
        }
    }

    // CREATE LEAD ACTIVITY
    handleLeadActivity(event, values) {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(CREATE_LEAD_ACTIVITY, {
                method: "POST",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    marketing_lead_id_encode: this.state.getById.id,
                    subject: values.subject,
                    description: values.description,
                    start_dt: values.startdate,
                    end_dt: values.enddate,
                    // contact_person: values.contactperson,
                    contact_person: "mittal",
                    expense: values.expense,           //** required **//
                    expense_description: values.expensedescription,
                    status: "Active"
                }),
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result == "true") {
                        toast("Lead Activity Created Successfully", {
                            type: "success",
                        });
                    }
                    else {
                        toast("Unable to Create Lead Activity", {
                            type: "error",
                        });
                    }
                });
            });
        } catch (error) {
            toast("Unable to Create Lead Activity", {
                type: "error",
            })
        }
    }


    // CREATE LEAD COMMENT
    handleLeadComments(events, values) {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(CREATE_LEAD_COMMENT, {
                method: "POST",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    marketing_lead_id_encode: this.state.getById.id,
                    comment_text: values.comment,
                    status: "Active"

                }),
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result == true) {
                        toast("Lead Comment Created Successfully", {
                            type: "success",
                        });
                    }
                    else {
                        toast("Unable to Create Lead Comment", {
                            type: "error",
                        });
                    }
                });
            });
        } catch (error) {
            toast("Unable to Create Lead Comment", {
                type: "error",
            });
            this.setState({
                isLoading: false,
            });

        }
    }

    // ALL DROPDOWN FIELDS
    async SearchLeadById(id) {
        var Token = localStorage.getItem("userToken");
        try {
            await fetch(
                GET_LEAD_REFERENCE_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                LeadDescription: data.data,
                            });
                        }
                    } else {
                    }
                });
            });
        } catch (error) {
        }
    }

    async SearchCompanyById(id) {
        var Token = localStorage.getItem("userToken");
        try {
            await fetch(
                GET_CUSTOMER_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                Companydescription: data.data,

                            });
                        }
                    } else {
                    }
                });
            });
        } catch (error) {
        }
    }

    async SearchContactPersonById(id) {
        var Token = localStorage.getItem("userToken");
        try {
            await fetch(
                GET_CONTACTPERSON_BY_ID + id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                ContactPersonDescription: data.data,
                                inputnumber: data.data.mobile_no_1
                            });
                        }
                    } else {
                    }
                });
            });
        } catch (error) {
        }
    }

    toggleCustomJustified(tab) {
        if (this.state.activeTabJustify !== tab) {
            this.setState({
                activeTabJustify: tab
            });
        }
    }

    async tog_xlarge() {
        await this.setState(prevState => ({
            modal_xlarge: !prevState.modal_xlarge
        }));
        this.removeBodyCss();
    }

    async ActivityModal() {
        await this.setState(prevState => ({
            ActivityModal: !prevState.ActivityModal
        }));
        this.removeBodyCss();
    }

    removeBodyCss() {
        document.body.classList.add("no_padding");
    }


    t_col1() {
        this.setState({ col1: !this.state.col1, col2: false, col3: false });
    }
    t_col2() {
        this.setState({ col2: !this.state.col2, col1: false, col3: false });
    }
    t_col3() {
        this.setState({ col3: !this.state.col3, col1: false, col2: false });
    }
    t_col5() {
        this.setState({ col5: !this.state.col5 });
    }

    // Function to format date
    formatDate = (dateString) => {
        const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
        const formattedDate = new Date(dateString).toLocaleDateString('en-GB', options);
        return formattedDate;
    };

    // Function to format date and time
    formatDateTime = (dateTimeString) => {
        const options = {
            hour: 'numeric',
            minute: 'numeric',
            second: 'numeric',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
        };
        const formattedDateTime = new Date(dateTimeString).toLocaleString('en-GB', options);
        return formattedDateTime;
    };

    handleStartDateChange = (event, value) => {
        this.setState({ selectedStartDate: value });
    };

    render() {
        const { displayedComments, LeadComments } = this.state;
        const { displayedCommentsforHistory, LeadLogs, historylistingloader, leadactivitylistingloader, LeadActivityDisplay, LeadActivity } = this.state;
        const { displayedLeadHistory, LeadHistoryTabledata, isLoading } = this.state;
        const { Paramdata } = this.state;
        const { defaultfile } = this.state;
        return (
            <React.Fragment>
                <div className="page-content">
                    <Container fluid>
                        <Breadcrumb title="Lead Dashboard" breadcrumbItems={this.state.breadcrumbItems} />
                        {this.state.isLoading1 ? (
                            <>
                                <ThreeDots
                                    height="80"
                                    width="80"
                                    radius="9"
                                    color="#4D5DC6"
                                    ariaLabel="three-dots-loading"
                                    wrapperStyle={{
                                        justifyContent: "center",
                                    }}
                                    wrapperClassName=""
                                    visible={true}
                                />
                            </>
                        ) : (
                            <>
                                <NameCard allUserData={Paramdata} />

                                <Row>
                                    <Col>
                                        <CardComp allUserData={Paramdata} />
                                    </Col>
                                </Row>
                                <Row >
                                    <Col md="10">
                                        <Nav variant="tabs" defaultActiveKey="link-1" >
                                            <Nav.Item>
                                                <Nav.Link eventKey="link-1" onClick={() => this.setState({ currentStep: "1" })} >Dashboard</Nav.Link>
                                            </Nav.Item>
                                            <Nav.Item>
                                                <Nav.Link eventKey="link-3" onClick={() => this.setState({ currentStep: "2" })}>History</Nav.Link>
                                            </Nav.Item>
                                            <Nav.Item>
                                                <Nav.Link eventKey="link-5" onClick={() => this.setState({ currentStep: "3" })} >
                                                    Activities
                                                </Nav.Link>
                                            </Nav.Item>
                                            <Nav.Item>
                                                <Nav.Link eventKey="link-7" onClick={() => this.setState({ currentStep: "4" })} >
                                                    Comments
                                                </Nav.Link>
                                            </Nav.Item>
                                        </Nav>
                                    </Col>
                                </Row>
                                <Row className="mt-1">
                                    <Col md="8">

                                        {this.state.currentStep == "1" && (
                                            <>
                                                <Row>
                                                    <Col>
                                                        <Card >
                                                            <CardBody>
                                                                <div>
                                                                    <h5>Total Meetings :</h5>  <>5</>
                                                                </div>
                                                            </CardBody>
                                                        </Card>
                                                    </Col>
                                                    <Col>
                                                        <Card >
                                                            <CardBody>
                                                                <h5>Lead Topic :</h5><>{this.state.getById.lead_topic} </>
                                                            </CardBody>
                                                        </Card>
                                                    </Col>
                                                    <Col>
                                                        <Card >
                                                            <CardBody>
                                                                <h5>Lead Type :</h5><>{this.state.getById.lead_type}</>
                                                            </CardBody>
                                                        </Card>
                                                    </Col>
                                                </Row>

                                                <Row>
                                                    <Col>
                                                        <Card>
                                                            <CardBody>
                                                                <Row className="mb-2">
                                                                    <Col>
                                                                        <h4 className="card-title">Comments</h4>
                                                                    </Col>
                                                                    {/* <Col>
                                                                        <Button onClick={this.tog_xlarge} style={{ float: "right" }} color="primary">
                                                                            <ImEye
                                                                                style={{
                                                                                    color: "#fffff",
                                                                                    width: "20px",
                                                                                    cursor: 'pointer',
                                                                                    alignSelf: "center"
                                                                                }}
                                                                            />
                                                                            View </Button>
                                                                    </Col> */}
                                                                </Row>
                                                                {/* <code>&lt;table&gt;</code>. */}
                                                                <div className="table-rep-plugin">
                                                                    <div className="table-responsive mb-0" data-pattern="priority-columns">
                                                                        <Table className="mb-0" bordered responsive>

                                                                            <thead>
                                                                                <tr>
                                                                                    <th>User Name</th>
                                                                                    <th>Comment</th>
                                                                                    <th>Date</th>
                                                                                    <th>Contact Person Name</th>
                                                                                </tr>
                                                                            </thead>
                                                                            <tbody>
                                                                                {LeadComments.length === 0 ? (
                                                                                    <tr>
                                                                                        <td colSpan="7" className="text-center">
                                                                                            No data found
                                                                                        </td>
                                                                                    </tr>
                                                                                ) : (
                                                                                    LeadComments.slice(0, displayedComments).map((item, index) => (
                                                                                        <tr>
                                                                                            <th >{item.name}</th>
                                                                                            <td>{item.comment_text}</td>
                                                                                            <td>{this.formatDate(item.created_at)}</td>
                                                                                            <td>Test User</td>
                                                                                        </tr>
                                                                                    ))
                                                                                )
                                                                                }
                                                                            </tbody>
                                                                        </Table>
                                                                        {displayedComments < LeadComments.length && (
                                                                            <button onClick={this.loadMoreComments} className="btn btn-link">
                                                                                Load More
                                                                            </button>
                                                                        )}
                                                                    </div>
                                                                </div>

                                                            </CardBody>
                                                        </Card>
                                                    </Col>
                                                </Row>
                                            </>
                                        )}

                                        {this.state.currentStep == "2" && (
                                            <>
                                                <Row>
                                                    <Col xs={12}>
                                                        <Card>
                                                            <CardBody>
                                                                <Row className="mb-2">
                                                                    <Col>
                                                                        <h4 className="card-title">History</h4>
                                                                    </Col>
                                                                    <Col>
                                                                        {/* <Button onClick={this.tog_xlarge} style={{ float: "right" }} color="primary">
                                                                            <ImEye
                                                                                style={{
                                                                                    color: "#fffff",
                                                                                    width: "20px",
                                                                                    cursor: 'pointer',
                                                                                    alignSelf: "center"
                                                                                }}
                                                                            />
                                                                            View </Button> */}
                                                                    </Col>
                                                                </Row>
                                                                <Row>
                                                                    <div className="table-rep-plugin">
                                                                        <div className="table-responsive mb-0" data-pattern="priority-columns">
                                                                            {historylistingloader ? (
                                                                                // Render loading state if needed
                                                                                <ThreeDots
                                                                                    height="80"
                                                                                    width="80"
                                                                                    radius="9"
                                                                                    color="#4D5DC6"
                                                                                    ariaLabel="three-dots-loading"
                                                                                    wrapperStyle={{
                                                                                        justifyContent: "center",
                                                                                    }}
                                                                                    wrapperClassName=""
                                                                                    visible={true}
                                                                                />
                                                                            ) : (
                                                                                <div>
                                                                                    <Table id="tech-companies-1" bordered responsive>
                                                                                        <thead>
                                                                                            <tr>

                                                                                                <th>Name</th>
                                                                                                <th>Action Type</th>
                                                                                                <th data-priority="1">Detail</th>
                                                                                                <th data-priority="3">Log Time</th>
                                                                                                <th data-priority="1">Last Updated</th>
                                                                                                <th data-priority="3">Create Date</th>
                                                                                            </tr>
                                                                                        </thead>
                                                                                        <tbody>
                                                                                            {LeadHistoryTabledata.length === 0 ? (
                                                                                                <tr>
                                                                                                    <td colSpan="7" className="text-center">
                                                                                                        No data found
                                                                                                    </td>
                                                                                                </tr>
                                                                                            ) : (

                                                                                                LeadHistoryTabledata.slice(0, displayedLeadHistory).map((item, index) => (
                                                                                                    <tr key={index}>
                                                                                                        {/* <th>GOOG <span className="co-name">Google Inc.</span></th> */}
                                                                                                        <td>{item.name}</td>
                                                                                                        <td>{item.action_type}</td>
                                                                                                        <td>{item.ldata}</td>
                                                                                                        <td>{this.formatDateTime(item.log_time)}</td>
                                                                                                        <td>{this.formatDate(item.updated_at)}</td>
                                                                                                        {/* <td>{item.updated_at}</td> */}
                                                                                                        <td>{this.formatDate(item.created_at)}</td>

                                                                                                    </tr>
                                                                                                ))

                                                                                            )}
                                                                                        </tbody>
                                                                                    </Table>
                                                                                    {displayedLeadHistory < LeadHistoryTabledata.length && (
                                                                                        <button onClick={this.loadMoreLeadHistory} className="btn btn-link">
                                                                                            Load More
                                                                                        </button>
                                                                                    )}
                                                                                </div>
                                                                            )}
                                                                        </div>
                                                                    </div>
                                                                </Row>
                                                            </CardBody>
                                                        </Card>
                                                    </Col>
                                                </Row>
                                            </>
                                        )}

                                        {this.state.currentStep == "3" && (
                                            <Row>
                                                <Col xs={12}>
                                                    <Card>
                                                        <CardBody>
                                                            <Row className="mb-2">
                                                                <Col>

                                                                    <h4 className="card-title">Activities</h4>
                                                                </Col>
                                                                <Col>
                                                                    <Button onClick={this.ActivityModal} style={{ float: "right" }} color="primary">
                                                                        Create Activity<i className="ri-add-fill align-middle ms-1"></i></Button>
                                                                </Col>
                                                            </Row>

                                                            <Row lg="12">
                                                                <div className="table-rep-plugin">
                                                                    <div className="table-responsive mb-0" data-pattern="priority-columns">
                                                                        {leadactivitylistingloader ? (
                                                                            <ThreeDots
                                                                                height="80"
                                                                                width="80"
                                                                                radius="9"
                                                                                color="#4D5DC6"
                                                                                ariaLabel="three-dots-loading"
                                                                                wrapperStyle={{
                                                                                    justifyContent: "center",
                                                                                }}
                                                                                wrapperClassName=""
                                                                                visible={true}
                                                                            />
                                                                        ) : (
                                                                            <div>
                                                                                <Table id="tech-companies-1" bordered responsive>
                                                                                    <thead>
                                                                                        <tr>
                                                                                            <th data-priority="1">Subject</th>
                                                                                            <th data-priority="3">Description</th>
                                                                                            <th data-priority="3">Contact Person</th>
                                                                                            <th data-priority="6">Expense</th>
                                                                                            <th data-priority="6">Expense Description</th>
                                                                                            <th data-priority="1">Start Date</th>
                                                                                            <th data-priority="3">End Date</th>
                                                                                        </tr>
                                                                                    </thead>
                                                                                    <tbody>
                                                                                        {LeadActivity.length === 0 ? (
                                                                                            <tr>
                                                                                                <td colSpan="7" className="text-center">
                                                                                                    No data found
                                                                                                </td>
                                                                                            </tr>
                                                                                        ) : (
                                                                                            LeadActivity.slice(0, LeadActivityDisplay).map((item, index) => (
                                                                                                <tr key={index}>
                                                                                                    <td>{item.subject}</td>
                                                                                                    <td>{item.description}</td>
                                                                                                    <td>{item.contact_person}</td>
                                                                                                    <td>{item.expense}</td>
                                                                                                    <td>{item.expense_description}</td>
                                                                                                    <td>{this.formatDate(item.start_dt)}</td>
                                                                                                    <td>{this.formatDate(item.end_dt)}</td>
                                                                                                </tr>
                                                                                            ))

                                                                                        )}
                                                                                    </tbody>
                                                                                </Table>
                                                                                <div>
                                                                                    <AvForm>
                                                                                        <Row lg="12" className="p-1 align-items-center">
                                                                                            <Col lg="1">
                                                                                                <img src={localStorage.getItem("userImage")} height={45} width={45} className="rounded-circle avatar-sm" alt="user-avatar" />
                                                                                            </Col>
                                                                                            {this.state.OpenTextArea == false ?
                                                                                                <Col lg="8" >
                                                                                                    <AvField
                                                                                                        name="comment"
                                                                                                        placeholder="Enter Comment ..."
                                                                                                        type="text"
                                                                                                        className="form-control mt-3"
                                                                                                        // validate={{ required: { value: true, errorMessage: 'Please enter a comment' } }}
                                                                                                        onClick={() => this.setState({ OpenTextArea: true })}
                                                                                                        id="validationCustom01"
                                                                                                    />
                                                                                                </Col>
                                                                                                : <><Col lg="8">
                                                                                                    <AvField
                                                                                                        name="comment"
                                                                                                        placeholder="Enter Comment ..."
                                                                                                        type="textarea"
                                                                                                        className="form-control mt-3"
                                                                                                        // validate={{ required: { value: true, errorMessage: 'Please enter a comment' } }}
                                                                                                        Onclick={() => this.setState({ OpenTextArea: true })}
                                                                                                        id="validationCustom01"
                                                                                                    />
                                                                                                </Col>

                                                                                                </>
                                                                                            }
                                                                                            <Col lg="3">
                                                                                            </Col>
                                                                                        </Row>
                                                                                    </AvForm>
                                                                                    <div className="border-top">
                                                                                        <h6 className="m-2 ">Other Comments</h6>
                                                                                        {LeadActivity.slice(0, LeadActivityDisplay).map((item, index) => (
                                                                                            <div>
                                                                                                <Row className="p-1 mt-1 align-items-center">
                                                                                                    <Col lg="1">
                                                                                                        <img src={localStorage.getItem("userImage")} height={45} width={45} className="rounded-circle avatar-sm" alt="user-avatar" />
                                                                                                    </Col>
                                                                                                    <Col lg="8" >
                                                                                                        <div >
                                                                                                            <h6>{item.subject}</h6>
                                                                                                            <>{this.formatDate(item.created_at)}</>
                                                                                                            <div className="font-size-12 text-muted">{item.description}</div>
                                                                                                        </div>

                                                                                                    </Col>
                                                                                                    <Col lg="3">
                                                                                                    </Col>
                                                                                                </Row>
                                                                                            </div>
                                                                                        ))
                                                                                        }
                                                                                    </div>
                                                                                </div>
                                                                                {/* Load More button */}
                                                                                {LeadActivityDisplay < LeadActivity.length && (
                                                                                    <button onClick={this.handleLoadMore} className="btn btn-link">
                                                                                        Load More
                                                                                    </button>
                                                                                )}
                                                                                {/* ... */}
                                                                            </div>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            </Row>
                                                        </CardBody>
                                                    </Card>
                                                </Col>
                                            </Row>
                                        )}

                                        {this.state.currentStep == "4" && (
                                            <Card>
                                                <CardBody>
                                                    <Row className="mb-2">
                                                        <Col>
                                                            <h4 className="card-title">Comments</h4>
                                                        </Col>
                                                        <Col>
                                                            <Button onClick={this.tog_xlarge} style={{ float: "right" }} color="primary">
                                                                Create Comment<i className="ri-add-fill align-middle ms-1"></i></Button>
                                                        </Col>
                                                    </Row>
                                                    <div className="table-rep-plugin">
                                                        <div className="table-responsive mb-0" data-pattern="priority-columns">
                                                            <Table className="mb-0" bordered responsive>

                                                                <thead>
                                                                    <tr>
                                                                        <th>User Name</th>
                                                                        <th>Comment</th>
                                                                        <th>Date</th>
                                                                        <th>Contact Person Name</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {LeadComments.length === 0 ? (
                                                                        <tr>
                                                                            <td colSpan="7" className="text-center">
                                                                                No data found
                                                                            </td>
                                                                        </tr>
                                                                    ) : (
                                                                        LeadComments.slice(0, displayedComments).map((item, index) => (
                                                                            <tr>
                                                                                <th >{item.name}</th>
                                                                                <td>{item.comment_text}</td>
                                                                                <td>{this.formatDate(item.created_at)}</td>
                                                                                <td>Test User</td>
                                                                            </tr>
                                                                        ))
                                                                    )
                                                                    }
                                                                </tbody>
                                                            </Table>
                                                            {displayedComments < LeadComments.length && (
                                                                <button onClick={this.loadMoreComments} className="btn btn-link">
                                                                    Load More
                                                                </button>
                                                            )}
                                                        </div>
                                                    </div>

                                                </CardBody>
                                            </Card>
                                        )}
                                    </Col>
                                    <Col md="4">
                                        <Card style={{ boxShadow: "5px 5px 10px 5px rgba(0, 0, 0, 0.1)" }}>
                                            <CardHeader>
                                                <h5 className="p-1">Basic Lead Details</h5>
                                            </CardHeader>
                                            <CardBody>
                                                {this.state.Cardloading ? (
                                                    <>
                                                        <ThreeDots
                                                            height="80"
                                                            width="80"
                                                            radius="9"
                                                            color="#4D5DC6"
                                                            ariaLabel="three-dots-loading"
                                                            wrapperStyle={{
                                                                justifyContent: "center",
                                                            }}
                                                            wrapperClassName=""
                                                            visible={true}
                                                        />
                                                    </>
                                                ) : (
                                                    <>
                                                        <Row>
                                                            <h6 className="mt-2 p-2 border-top border-bottom"><b>Lead Details </b></h6>
                                                            <Col >

                                                                <div className="p-2">
                                                                    <b>Lead Topic:</b> {this.state.getById.lead_topic}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Lead Nature:</b> {this.state.getById.nature_of_lead}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Lead Type:</b> {this.state.getById.lead_type}
                                                                </div>
                                                            </Col>
                                                            <Col>
                                                                <div className="p-2">
                                                                    <b>Lead Status:</b> {this.state.getById.lead_status}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Priority:</b> {this.state.getById.priority}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Lead Topic:</b> {this.state.getById.lead_topic}
                                                                </div>
                                                            </Col>
                                                        </Row>

                                                        <Row className="mt-2  border-top">
                                                            <h6 className="p-2 border-bottom"><b>Company Details</b></h6>
                                                            <Col lg="6">
                                                                <div className="p-2">
                                                                    <b>Company Name:</b> {this.state.Companydescription.company_name}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Customer Category:</b> {this.state.Companydescription.customer_category}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Customer Type:</b> {this.state.Companydescription.customer_type}
                                                                </div>
                                                            </Col>
                                                            <Col lg="6">
                                                                <div className="p-2">
                                                                    <b>Customer Field Description :</b> {this.state.getById.customer_field_description}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Ownership Type:</b> {this.state.Companydescription.ownership_name}
                                                                </div>
                                                            </Col>
                                                        </Row>

                                                        <Row className="mt-2  border-top">
                                                            <h6 className="p-2 border-bottom"><b>Reference Details</b></h6>
                                                            <Col lg="6">
                                                                <div className="p-2">
                                                                    <b>Lead Reference Type:</b>{this.state.LeadDescription.name}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Lead Reference Description:</b> {this.state.LeadDescription.description}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Reference Person Details:</b> {this.state.getById.reference_person_description}
                                                                </div>
                                                            </Col>
                                                            <Col lg="6">
                                                                <div className="p-2">
                                                                    <b>Comment:</b> {this.state.getById.comments}
                                                                </div>
                                                            </Col>
                                                        </Row>

                                                        <Row className="mt-2  border-top">
                                                            <h6 className="p-2 border-bottom"><b>Contact Person Details</b></h6>
                                                            <Col lg="6">
                                                                <div className="p-2">
                                                                    <b>Contact Person:</b>{this.state.ContactPersonDescription?.first_name + " " + this.state.ContactPersonDescription?.last_name}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Contact Person Phone No:</b> {this.state.inputnumber}
                                                                </div>
                                                                <div className="p-2">
                                                                    <b>Contact Person Designation:</b> {this.state.ContactPersonDescription?.designation_name}
                                                                </div>
                                                            </Col>
                                                            <Col lg="6">
                                                                <div className="p-2">
                                                                    <b>Contact Person Department:</b> {this.state.ContactPersonDescription?.department_name}
                                                                </div>
                                                            </Col>
                                                        </Row>
                                                    </>
                                                )}
                                            </CardBody>
                                        </Card>
                                    </Col>
                                </Row>


                                {/* CREATE COMMENT */}
                                <Modal
                                    // size="xl"
                                    isOpen={this.state.modal_xlarge}
                                    toggle={this.tog_xlarge} >
                                    <ModalHeader toggle={() => this.setState({ modal_xlarge: false })}>
                                        Create Lead Comment
                                    </ModalHeader>
                                    <ModalBody>
                                        <Row>
                                            <Col md="12">
                                                <AvForm
                                                    className="needs-validation"
                                                    onValidSubmit={this.handleLeadComments}>
                                                    <Row className="mt-2">
                                                        <Col md="10" className="d-inline">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom04"
                                                            >
                                                                Comment
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                name="comment"
                                                                type="text"
                                                                id="validationCustom04"
                                                                errorMessage="Please Select a subject."
                                                                validate={{ required: { value: true } }}
                                                                className="form-control"
                                                            >
                                                            </AvField>
                                                        </Col>
                                                    </Row>
                                                    <Button color="primary" type="submit" >
                                                        Create Comment
                                                    </Button>
                                                </AvForm>
                                            </Col>
                                            {/* <Col md="4">
                                                <div id="accordion">
                                                    <Card className="mb-1 shadow-none">
                                                        <Link to="#" onClick={this.t_col1} style={{ cursor: "pointer" }} className="text-dark" >
                                                            <CardHeader id="headingOne">
                                                                <h6 className="m-0 font-14">
                                                                    More Details
                                                                    <i className={this.state.col1 ? "mdi mdi-minus float-end accor-plus-icon" : "mdi mdi-plus float-end accor-plus-icon"}></i>
                                                                </h6>
                                                            </CardHeader>
                                                        </Link>
                                                        <Collapse isOpen={this.state.col1}>
                                                            <CardBody>
                                                                Name : User 1
                                                                <br />
                                                                Lead Update : Last Meeting has been cancelled
                                                                <br />
                                                            </CardBody>
                                                        </Collapse>
                                                    </Card>
                                                    <Card className="mb-1 shadow-none">
                                                        <Link to="#" onClick={this.t_col2} style={{ cursor: "pointer" }} className="text-dark" >
                                                            <CardHeader id="headingTwo">
                                                                <h6 className="m-0 font-14">
                                                                    {" "}Further Details{" "}
                                                                    <i className={this.state.col2 ? "mdi mdi-minus float-end accor-plus-icon" : "mdi mdi-plus float-end accor-plus-icon"}></i>
                                                                </h6>
                                                            </CardHeader>
                                                        </Link>
                                                        <Collapse isOpen={this.state.col2}>
                                                            <CardBody>
                                                                <br />
                                                                Lead Update : Next Meeting has been fixed
                                                                <br />
                                                            </CardBody>
                                                        </Collapse>{" "}
                                                    </Card>
                                                </div>
                                            </Col> */}
                                        </Row>
                                    </ModalBody>
                                </Modal>

                                {/* CREATE ACTIVITY MODAL */}
                                <Modal
                                    size="xl"
                                    isOpen={this.state.ActivityModal}
                                    toggle={this.ActivityModal}
                                >
                                    <ModalHeader toggle={() => this.setState({ ActivityModal: false })}>
                                        Create Activity
                                    </ModalHeader>
                                    <ModalBody>
                                        <Row>
                                            <Col md="12">
                                                <AvForm
                                                    className="needs-validation"
                                                    onValidSubmit={this.handleLeadActivity}
                                                >
                                                    <Row className="mt-2">
                                                        <Col md="6" className="d-inline">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom04"
                                                            >
                                                                Subject
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                required={true}
                                                                name="subject"
                                                                type="text"
                                                                id="validationCustom04"
                                                                errorMessage="Please Select a subject."
                                                                validate={{ required: { value: true } }}
                                                                className="form-control"
                                                            >
                                                            </AvField>
                                                        </Col>
                                                        <Col md="6" className="d-inline">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom04"
                                                            >
                                                                Description
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                required={true}
                                                                name="description"
                                                                type="text"
                                                                id="validationCustom04"
                                                                // value={this.state.selectedcountry}
                                                                errorMessage="Please Select text."
                                                                validate={{ required: { value: true } }}
                                                                className="form-control"
                                                            >
                                                            </AvField>
                                                        </Col>
                                                        <Col md="6" className="d-inline">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom04"
                                                            >
                                                                Start Date
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                required={true}
                                                                name="startdate"
                                                                type="date"
                                                                id="validationCustom04"
                                                                // value={this.state.selectedcountry}
                                                                errorMessage="Please Select a start date."
                                                                validate={{ required: { value: true } }}
                                                                className="form-control"
                                                                onChange={this.handleStartDateChange}
                                                            >
                                                            </AvField>
                                                        </Col>
                                                        <Col md="6" className="d-inline">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom04"
                                                            >
                                                                End Date
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                required={true}
                                                                name="enddate"
                                                                type="date"
                                                                id="validationCustom04"
                                                                // value={this.state.selectedcountry}
                                                                errorMessage="Please select end date."
                                                                validate={{ required: { value: true } }}
                                                                className="form-control"
                                                                min={this.state.selectedStartDate ? this.state.selectedStartDate : ""}
                                                            >
                                                            </AvField>
                                                        </Col>
                                                        <Col md="6" className="d-inline">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom04"
                                                            >
                                                                Expense
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                min="0"
                                                                required={true}
                                                                name="expense"
                                                                type="number"
                                                                id="validationCustom04"
                                                                // value={this.state.selectedcountry}
                                                                errorMessage="Please enter expense."
                                                                validate={{ required: { value: true } }}
                                                                className="form-control"
                                                            >
                                                            </AvField>
                                                        </Col>
                                                        <Col md="6" className="d-inline">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom04"
                                                            >
                                                                Expense Description
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                name="expensedescription"
                                                                type="textarea"
                                                                id="validationCustom04"
                                                                // value={this.state.selectedcountry}
                                                                errorMessage="Please enter an expense description."
                                                                validate={{ required: { value: true } }}
                                                                className="form-control"
                                                            >
                                                            </AvField>
                                                        </Col>
                                                    </Row>

                                                    <Button color="primary" type="submit" >
                                                        Create Activity
                                                    </Button>
                                                </AvForm>
                                            </Col>
                                            {/* <Col md="4">
                                                <div id="accordion">
                                                    <Card className="mb-1 shadow-none">
                                                        <Link to="#" onClick={this.t_col1} style={{ cursor: "pointer" }} className="text-dark" >
                                                            <CardHeader id="headingOne">
                                                                <h6 className="m-0 font-14">
                                                                    More Details
                                                                    <i className={this.state.col1 ? "mdi mdi-minus float-end accor-plus-icon" : "mdi mdi-plus float-end accor-plus-icon"}></i>
                                                                </h6>
                                                            </CardHeader>
                                                        </Link>
                                                        <Collapse isOpen={this.state.col1}>
                                                            <CardBody>
                                                                Name : User 1
                                                                <br />
                                                                Lead Update : Last Meeting has been cancelled
                                                                <br />
                                                            </CardBody>
                                                        </Collapse>
                                                    </Card>
                                                    <Card className="mb-1 shadow-none">
                                                        <Link to="#" onClick={this.t_col2} style={{ cursor: "pointer" }} className="text-dark" >
                                                            <CardHeader id="headingTwo">
                                                                <h6 className="m-0 font-14">
                                                                    {" "}Further Details{" "}
                                                                    <i className={this.state.col2 ? "mdi mdi-minus float-end accor-plus-icon" : "mdi mdi-plus float-end accor-plus-icon"}></i>
                                                                </h6>
                                                            </CardHeader>
                                                        </Link>
                                                        <Collapse isOpen={this.state.col2}>
                                                            <CardBody>
                                                                <br />
                                                                Lead Update : Next Meeting has been fixed
                                                                <br />
                                                            </CardBody>
                                                        </Collapse>{" "}
                                                    </Card>
                                                </div>
                                            </Col> */}
                                        </Row>

                                    </ModalBody>
                                </Modal>

                            </>
                        )}
                    </Container>
                </div >
            </React.Fragment >
        );
    };
};

export default ViewMarketLead1;
