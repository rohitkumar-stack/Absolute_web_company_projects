import React, { Component } from "react";
//Import Breadcrumb
import Breadcrumb from "../../../components/Common/Breadcrumb";
import { AvForm, AvField, AvRadioGroup, AvRadio } from "availity-reactstrap-validation";
import PhoneInput from "react-phone-input-2";
// import Dropzone from "react-dropzone";
// import { Link } from "react-router-dom";
import 'react-phone-input-2/lib/style.css'
import { toast } from "react-toastify";
import { CREATE_DEPARTMENT, CREATE_DESIGNATION, CREATE_DOCUMENT_LEAD, CREATE_ITEM_CATEGORY, CREATE_ITEM_MAKER, CREATE_LEAD_REFERENCE, CREATE_LEAVE, CREATE_MARKETING_LEAD, CREATE_SHIFT, CREATE_SUBITEM_CATEGORY, CREATE_TERMS_CONDITIONS, CREATE_UNIT, CREATE_UNIT_MEASURE, CREATE_USER, CREATE_WAREHOUSE, GET_ALL_CUSTOMER_WO_PAGINATION, GET_CONTACTPERSON_BY_ID, GET_CONTACTPERSON_WO_PAGINATE, GET_COUNTRY, GET_CUSTOMER_BY_ID, GET_ITEM_CATEGORY, GET_LEAD_REFERENCE_BY_ID, GET_LEAD_REFERENCE_WO_PAGINATE, GET_OWNERSHIP_WO_PAGINATE } from "../../../globals";
import CustomFileInputNew from "../../../components/Common/imagefunction";
import Dropzone from "react-dropzone";
import { Link } from "react-router-dom/cjs/react-router-dom.min";
import { Row, Col, Card, CardBody, TabContent, TabPane, NavItem, NavLink, Label, Input, Form, Progress, Container, Button, Table } from "reactstrap";
import classnames from 'classnames';
import { RiDeleteBin6Line } from "react-icons/ri";

class MarketLeadForWizard extends Component {
    constructor(props) {
        super(props);
        this.state = {
            breadcrumbItems: [
                { title: "Market Lead", link: process.env.PUBLIC_URL + "/marketingleadlist" },
                { title: "Create Market Lead", link: process.env.PUBLIC_URL + "/#" },
            ],
            selectedFiles: [],
            Img: "",
            status: "Active",
            inputMobileField: "",
            Night: "0",
            morning: "0",
            isAadharBase64URL: "",
            fileData: "",
            itemcategory: [],
            Leadreferencelist: [],
            customerlist: [],
            selectedlead: "",
            LeadDescription: "",
            Companydescription: "",
            selectedCopmany: "",
            ownershiplist: [],
            contactpersonlist: [],
            selectedcontactperson: "",
            ContactPersonDescription: "",
            activeTab: 1,
            leadvalue: "",
            lead_topic: "",
            nature_of_lead: "",
            lead_type: "",
            lead_status: "",
            lead_reference_id_encode: "",
            reference_person_description: "",
            customer_id_encode: "",
            customer_field_description: "",
            contact_person_id_encode: "",
            comments: "",
            status: "",
            document_type: "",
            document_name: "",
            document_url_encode: "",
            selectedFiles: [],
            rows: [
                {
                    id: "",
                    document_name: "",
                    document_type: "",
                    document_url_encode: "",
                }],


        };
        this.handleSubmit = this.handleSubmit.bind(this);
        this.toggleTab.bind(this);
        this.toggleTabProgress.bind(this);
    };


    toggleTab(tab) {
        if (this.state.activeTab !== tab) {
            if (tab >= 1 && tab <= 5) {
                this.setState({
                    activeTab: tab
                });
            }
        }
    }

    toggleTabProgress(tab) {
        if (this.state.activeTabProgress !== tab) {
            if (tab >= 1 && tab <= 5) {
                this.setState({
                    activeTabProgress: tab
                });
                if (tab === 1) { this.setState({ progressValue: 25 }) }
                if (tab === 2) { this.setState({ progressValue: 50 }) }
                if (tab === 3) { this.setState({ progressValue: 75 }) }
                if (tab === 4) { this.setState({ progressValue: 100 }) }
            }
        }
    }

    componentDidMount() {
        this.GetAllReferenceId();
        this.getAllCustomers();
        this.GetAllOwnership();
        this.getAllContacts();

    }


    // GET ALL SENDERS
    async GetAllReferenceId() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_LEAD_REFERENCE_WO_PAGINATE, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ Leadreferencelist: data.data });
                    }
                    else if (data.result === false) {
                        toast(data.message, {
                            type: "error",
                        });
                    }
                    else {

                    }
                });
            });
        } catch (error) {

        }
    }

    // GET ALL SENDERS
    async getAllCustomers() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_ALL_CUSTOMER_WO_PAGINATION, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ customerlist: data.data });
                    }
                    else if (data.result === false) {
                        toast(data.message, {
                            type: "error",
                        });
                    }
                    else {

                    }
                });
            });
        } catch (error) {

        }
    }
    // GET ALL SENDERS
    async getAllContacts() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_CONTACTPERSON_WO_PAGINATE, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ contactpersonlist: data.data });
                    }
                    else if (data.result === false) {
                        toast(data.message, {
                            type: "error",
                        });
                    }
                    else {

                    }
                });
            });
        } catch (error) {

        }
    }


    // handleAcceptedFiles = (files) => {
    //     this.getBase64Icon(files);

    //     files.map((file) =>
    //         Object.assign(file, {
    //             preview: URL.createObjectURL(file),

    //         })
    //     );
    //     this.setState({ selectedFiles: files });
    // };


    handleAcceptedFiles = (files) => {
        // Use the FileReader API to read the content of each file and convert it to base64
        const promises = files.map((file) => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (event) => {
                    // Resolve with the base64 data
                    resolve({
                        ...file,
                        base64: event.target.result,
                        preview: URL.createObjectURL(file),
                    });
                };
                reader.onerror = (error) => {
                    // Reject with the error
                    reject(error);
                };
                reader.readAsDataURL(file);
            });
        });

        // Wait for all promises to resolve
        Promise.all(promises)
            .then((filesWithBase64) => {
                // Set the state with the updated files
                this.setState({ selectedFiles: filesWithBase64 });
            })
            .catch((error) => {
                console.error('Error reading file:', error);
            });
    };

    async getBase64Icon(files) {
        const file = files[0];
        if (file) {

            const reader = new FileReader();
            reader.readAsDataURL(file);

            reader.onload = () => {
                const base64Data = reader.result;
                let base64Split = base64Data.split(",");
                const Img = base64Split[1];
                this.setState({ Img: Img });
            };

            reader.onerror = (error) => {
                console.error("Error occurred while reading the file:", error);
            };
        }
    }

    // GET ALL OWNERSHIP GROUP
    async GetAllOwnership() {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(GET_OWNERSHIP_WO_PAGINATE, {
                method: "GET",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        this.setState({ ownershiplist: data.data });
                    } else {

                    }
                });
            });
        } catch (error) {

        }
    }

    async StepOneSubmit(event, values) {
        console.log("VALUES FROM STEP 1 ", values);
        await this.setState({
            leadvalue: values.leadtopic,
            lead_topic: values.leadtopic,
            nature_of_lead: values.leadnature,
            lead_type: values.leadtype,
            lead_status: values.leadstatus,
            lead_reference_id_encode: values.selectedleadreference,
            reference_person_description: values.referencepersondetails,
            comments: values.comment,
            activeTab: 2,
        })
        // this.handleSubmit();
    }

    async StepTwoSubmit(event, values) {
        console.log("VALUES FROM STEP 2 ", values);
        await this.setState({
            customer_id_encode: values.customerid,
            customer_field_description: values.customerfielddescription,
            contact_person_id_encode: values.selectedcontactperson,

            activeTab: 3,
        })

    }

    async StepThreeSubmit(event, values) {
        console.log("VALUES FROM STEP 3 ", values);
        await this.setState({
            contact_person_id_encode: values.selectedcontactperson,
            activeTab: 4,
        })

    }

    async StepFourSubmit(event, values) {
        console.log("STEP 4", values);
        await this.setState({
            document_type: values.documenttype,
            document_name: values.documentname,
            // document_url_encode: this.state.selectedFiles[0].base64.split(",")[1],
            status: "Active",
        })
        this.FinalSubmit();
    }



    // CREATE LEAD API
    handleSubmit(event, values) {
        if (this.state.activeTab == 1) {
            this.StepOneSubmit(event, values);
        }
        else if (this.state.activeTab == 2) {
            this.StepTwoSubmit(event, values);
        }
        else if (this.state.activeTab == 3) {
            this.StepThreeSubmit(event, values);
        }
        else if (this.state.activeTab == 4) {
            this.StepFourSubmit(event, values);
        }
        else {
            return
        }
        return

    }

    addRow = () => {
        this.setState(prevState => ({
            rows: [...prevState.rows, {}], // Add a new empty row object to the array
        }));
    };

    deleteRow = (Index) => {
        if (Index >= 1) {
            this.setState(prevState => ({
                rows: prevState.rows.filter((_, i) => i !== Index), // Remove the row at the specified index
            }));
        }
    };



    async FinalSubmit() {
        var Token = localStorage.getItem("userToken");
        try {
            var raw = JSON.stringify({
                lead_topic: this.state.lead_topic,
                nature_of_lead: this.state.nature_of_lead,
                lead_type: this.state.lead_type,
                lead_status: this.state.lead_status,
                lead_reference_id_encode: this.state.lead_reference_id_encode,
                reference_person_description: this.state.reference_person_description,
                customer_id_encode: this.state.customer_id_encode,
                customer_field_description: this.state.customer_field_description,
                contact_person_id_encode: this.state.contact_person_id_encode,
                comments: this.state.comments,
                status: "Active",

            });
            fetch(CREATE_MARKETING_LEAD, {
                method: "POST",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
                body: raw,
            }).then((response) => {
                response.json().then((data) => {
                    console.log(data);
                    if (data.result === true) {
                        console.log("DATA RESULT == true");
                        // toast("Market Lead Created Successfully !", {
                        //     type: "success",
                        // });
                        // this.setState({Leadid:data.data.id})
                        this.CreateLeadDocument(data.data.id);

                        // this.props.history.goBack();
                    }
                    else if (data.result === false) {
                        toast(data.message, {
                            type: "error",
                        });
                    }
                    else {
                        toast("Unable to Create Market Lead", {
                            type: "error",
                        });
                    }
                });
            });
        } catch (error) {
            toast("Unable to create Market Lead", {
                type: "error",
            });

        }
    }

    // DOCUMENT CREATE API
    async CreateLeadDocument(leadid) {
        var Token = localStorage.getItem("userToken");
        try {
            var raw = JSON.stringify({
                marketing_lead_id_encode: leadid,
                document_type: this.state.document_type,
                document_name: this.state.document_name,
                documents: this.state.rows,
                status: "Active"
            });
            fetch(CREATE_DOCUMENT_LEAD, {
                method: "POST",
                headers: {
                    Authorization: "Bearer " + Token,
                    "Content-Type": "application/json",
                },
                body: raw,
            }).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        toast("Market Lead Created Successfully !", {
                            type: "success",
                        });
                        this.setState({ activeTab: 5 })
                        this.props.history.push(process.env.PUBLIC_URL + "/marketingleadlist");
                    }
                    else if (data.result === false) {
                        toast(data.message, {
                            type: "error",
                        });
                    }
                    else {
                        toast("Unable to Create Market Lead", {
                            type: "error",
                        });
                    }
                });
            });
        } catch (error) {
            toast("Unable to create Market Lead", {
                type: "error",
            });

        }

    }


    handleAcceptedFiles = (files) => {
        // Use the FileReader API to read the content of each file and convert it to base64
        const promises = files.map((file) => {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (event) => {
                    // Resolve with the base64 data
                    resolve({
                        ...file,
                        base64: event.target.result,
                        preview: URL.createObjectURL(file),
                    });
                };
                reader.onerror = (error) => {
                    // Reject with the error
                    reject(error);
                };
                reader.readAsDataURL(file);
            });
        });

        // Wait for all promises to resolve
        Promise.all(promises)
            .then((filesWithBase64) => {
                // Set the state with the updated files
                this.setState({ selectedFiles: filesWithBase64 });
            })
            .catch((error) => {
                console.error('Error reading file:', error);
            });
    };


    // ALL DROPDOWN FIELDS
    async SearchLeadById(id) {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                GET_LEAD_REFERENCE_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                LeadDescription: data.data.description,
                            });
                        }
                    } else {
                    }
                });
            });
        } catch (error) {
        }
    }


    async SearchCompanyById(id) {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                GET_CUSTOMER_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                Companydescription: data.data,
                            });
                        }
                    } else {
                    }
                });
            });
        } catch (error) {
        }
    }

    async SearchContactPersonById(id) {
        var Token = localStorage.getItem("userToken");
        try {
            fetch(
                GET_CONTACTPERSON_BY_ID +
                id,
                {
                    method: "GET",
                    headers: {
                        Authorization: "Bearer " + Token,
                        "Content-Type": "application/json",
                    },
                }
            ).then((response) => {
                response.json().then((data) => {
                    if (data.result === true) {
                        if (data.data) {
                            this.setState({
                                ContactPersonDescription: data.data,
                            });
                        }
                    } else {
                    }
                });
            });
        } catch (error) {
        }
    }

    handleFileChange = (e, index) => {
        const { rows } = this.state;
        const file = e.target.files[0];

        if (file) {
            const reader = new FileReader();
            reader.readAsDataURL(file);

            reader.onload = () => {
                const base64Data = reader.result;
                // let base64Split = base64Data.split(",");
                rows[index].document_url_encode = base64Data;
                this.setState({ rows });
            };

            reader.onerror = (error) => {
                console.error('Error occurred while reading the file:', error);
            };
        }
    };


    // Callback function to handle file data
    handleFileDataChange = (file) => {
        this.setState({ fileData: file });
    };


    handleAadharBase64DataChange = (base64) => {
        this.setState({ isAadharBase64URL: base64 });
    };


    render() {
        const { isAadharBase64URL, fileData } = this.state;
        const { isView } = this.props;
        return (
            <React.Fragment>
                <div className="page-content">
                    <Container fluid>
                        <Breadcrumb title="Add Market Lead" breadcrumbItems={this.state.breadcrumbItems} />
                        {/* <AvForm
                            className="needs-validation"
                            onValidSubmit={this.handleSubmit}
                        // onSubmit={this.submitStep1}
                        > */}
                        <Col lg="12">
                            <Card>
                                <CardBody>
                                    <h4 className="card-title mb-4">Lead Details</h4>

                                    <div id="basic-pills-wizard" className="twitter-bs-wizard">
                                        <ul className="twitter-bs-wizard-nav nav nav-pills nav-justified">
                                            <NavItem>
                                                <NavLink className={classnames({ active: this.state.activeTab === 1 })}   >
                                                    <span className="step-number">01</span>
                                                    <span className="step-title">Lead Details</span>
                                                </NavLink>
                                            </NavItem>
                                            <NavItem>
                                                <NavLink className={classnames({ active: this.state.activeTab === 2 })}  >
                                                    <span className="step-number">02</span>
                                                    <span className="step-title">Company Details</span>
                                                </NavLink>
                                            </NavItem>
                                            <NavItem>
                                                <NavLink className={classnames({ active: this.state.activeTab === 3 })}  >
                                                    <span className="step-number">03</span>
                                                    <span className="step-title">Contact Person Details</span>
                                                </NavLink>
                                            </NavItem>
                                            <NavItem>
                                                <NavLink className={classnames({ active: this.state.activeTab === 4 })} onClick={() => this.setState({ activeTab: 4 })} >
                                                    <span className="step-number">04</span>
                                                    <span className="step-title">Lead Document Details</span>
                                                </NavLink>
                                            </NavItem>
                                            <NavItem>
                                                <NavLink className={classnames({ active: this.state.activeTab === 5 })} >
                                                    <span className="step-number">05</span>
                                                    <span className="step-title">Confirm Details</span>
                                                </NavLink>
                                            </NavItem>
                                        </ul>

                                        <TabContent activeTab={this.state.activeTab} className="twitter-bs-wizard-tab-content">
                                            <TabPane tabId={1}>
                                                <AvForm
                                                    className="needs-validation"
                                                    onValidSubmit={this.handleSubmit}
                                                // onSubmit={this.submitStep1}
                                                >
                                                    <Row className="mt-2">
                                                        <Col lg="4">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom01"
                                                            >
                                                                Lead Topic
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                name="leadtopic"
                                                                placeholder="Lead Topic"
                                                                type="text"
                                                                errorMessage="Please Provide Lead Topic"
                                                                className="form-control"
                                                                validate={{ required: { value: true } }}
                                                                id="validationCustom01"
                                                            />
                                                        </Col>

                                                        <Col lg="4">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom01"
                                                            >
                                                                Lead Nature
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                name="leadnature"
                                                                placeholder="Lead Nature"
                                                                type="select"
                                                                errorMessage="Please Provide Lead Nature"
                                                                className="form-control"
                                                                validate={{ required: { value: true } }}
                                                                id="validationCustom01"
                                                            >
                                                                <option value={""} >Select Lead Nature</option>
                                                                <option value={"Lead Nature 1"} >Lead Nature 1</option>
                                                                <option value={"Lead Nature 2"} >Lead Nature 2</option>
                                                            </AvField>
                                                        </Col>
                                                        <Col lg="4">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom01"
                                                            >
                                                                Lead Type
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                name="leadtype"
                                                                placeholder="Lead Type"
                                                                type="select"
                                                                errorMessage="Please Provide Lead Type"
                                                                className="form-control"
                                                                validate={{ required: { value: true } }}
                                                                id="validationCustom01"
                                                            >
                                                                <option value={""} >Select Lead Type</option>
                                                                <option value={"Lead Type 1"} >Lead Type 1</option>
                                                                <option value={"Lead Type 2"} >Lead Type 2</option>
                                                            </AvField>
                                                        </Col>
                                                        <Col lg="4">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom01"
                                                            >
                                                                Lead Status
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                name="leadstatus"
                                                                placeholder="Lead Status"
                                                                type="select"
                                                                errorMessage="Please Provide Lead Status"
                                                                className="form-control"
                                                                validate={{ required: { value: true } }}
                                                                id="validationCustom01"

                                                            >
                                                                <option value={""} >Select Lead Satus</option>
                                                                <option value={"Ready"} >Ready</option>
                                                                <option value={"in Progress"} >in Progress</option>
                                                                <option value={"Success"} >Success</option>
                                                                <option value={"Failed"} >Failed</option>

                                                            </AvField>
                                                        </Col>
                                                        <Col lg="4" className="d-inline">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom04"
                                                            >
                                                                Lead Reference Type
                                                                <span style={{ color: "#ff0000" }}>*</span>
                                                            </Label>
                                                            <AvField
                                                                required={true}
                                                                name="selectedleadreference"
                                                                type="select"
                                                                id="validationCustom04"
                                                                // value={this.state.selectedleadreference}
                                                                errorMessage="Please Select a Lead Reference Type."
                                                                validate={{ required: { value: true } }}
                                                                className="form-control"
                                                                onChange={(e) => {
                                                                    this.setState({
                                                                        selectedlead: e.target.value,
                                                                    });
                                                                    if (e.target.value != "") {
                                                                        this.SearchLeadById(e.target.value)
                                                                    }
                                                                }}
                                                            >
                                                                <option value={""} >Select Reference Type</option>
                                                                {this.state.Leadreferencelist.map((item) => {
                                                                    return (
                                                                        <option value={item.id}>{item.name}</option>

                                                                    );
                                                                })}
                                                            </AvField>
                                                        </Col>
                                                        {this.state.selectedlead != "" &&
                                                            (<>
                                                                <Col lg="4">
                                                                    <Label
                                                                        className="form-label"
                                                                        htmlFor="validationCustom01"
                                                                    >
                                                                        Lead Reference Description
                                                                        <span style={{ color: "#ff0000" }}>*</span>
                                                                    </Label>
                                                                    <AvField
                                                                        value={this.state.LeadDescription}
                                                                        disabled
                                                                        name="referenceusername"
                                                                        placeholder="Lead Reference Description"
                                                                        type="text"
                                                                        // errorMessage="Please Provide Lead Reference Description"
                                                                        className="form-control"
                                                                        // validate={{ required: { value: true } }}
                                                                        id="validationCustom01"
                                                                    />
                                                                </Col>

                                                            </>
                                                            )}
                                                        <Col lg="4">
                                                            <Label
                                                                className="form-label"
                                                                htmlFor="validationCustom01"
                                                            >
                                                                Reference Person Details
                                                                {/* <span style={{ color: "#ff0000" }}>*</span> */}
                                                            </Label>
                                                            <AvField
                                                                // value={this.state.LeadDescription}
                                                                // disabled
                                                                name="referencepersondetails"
                                                                placeholder="Reference Person Details"
                                                                type="text"
                                                                // errorMessage="Please Provide Reference Person Details"
                                                                className="form-control"
                                                                // validate={{ required: { value: true } }}
                                                                id="validationCustom01"
                                                            />
                                                        </Col>
                                                    </Row>
                                                    <Col lg="12">
                                                        <Label
                                                            className="form-label"
                                                            htmlFor="validationCustom01"
                                                        >
                                                            Comment
                                                            <span style={{ color: "#ff0000" }}>*</span>
                                                        </Label>
                                                        <AvField
                                                            name="comment"
                                                            placeholder="Comment"
                                                            type="textarea"
                                                            errorMessage="Please Provide Comment"
                                                            className="form-control"
                                                            validate={{ required: { value: true } }}
                                                            id="validationCustom01"
                                                        />
                                                    </Col>
                                                    <div className="d-flex justify-content-between mt-5">
                                                        <Button color="primary" type="submit" className={this.state.activeTab === 1 ? "previous disabled" : "previous"}>Previous</Button>
                                                        <Button color="primary" type="submit" style={{ float: "right" }}>Next</Button>
                                                    </div>
                                                </AvForm>
                                            </TabPane>
                                            <TabPane tabId={2}>
                                                <div>
                                                    <AvForm
                                                        className="needs-validation"
                                                        onValidSubmit={this.handleSubmit}
                                                    // onSubmit={this.submitStep1}
                                                    >
                                                        <Row>
                                                            <Col lg="4" className="d-inline">
                                                                <Label
                                                                    className="form-label"
                                                                    htmlFor="validationCustom04"
                                                                >
                                                                    Select Company Name
                                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                                </Label>
                                                                <AvField
                                                                    required={true}
                                                                    name="customerid"
                                                                    type="select"
                                                                    id="validationCustom04"
                                                                    // value={this.state.selectedleadreference}
                                                                    errorMessage="Please Select a Company Name."
                                                                    validate={{ required: { value: true } }}
                                                                    className="form-control"
                                                                    onChange={(e) => {
                                                                        this.setState({
                                                                            selectedCopmany: e.target.value,
                                                                        });
                                                                        if (e.target.value != "") {
                                                                            this.SearchCompanyById(e.target.value)
                                                                        }
                                                                    }}
                                                                >
                                                                    <option value={""} >Select Company Name</option>
                                                                    <option value={""} >Other</option>
                                                                    {this.state.customerlist.map((item) => {
                                                                        return (
                                                                            <option value={item.id}>{item.company_name}</option>

                                                                        );
                                                                    })}

                                                                </AvField>
                                                            </Col>
                                                            {this.state.selectedCopmany && (
                                                                <>
                                                                    <Col lg="4">
                                                                        <Label
                                                                            className="form-label"
                                                                            htmlFor="validationCustom01"
                                                                        >
                                                                            Customer Category
                                                                            <span style={{ color: "#ff0000" }}>*</span>
                                                                        </Label>
                                                                        <AvField
                                                                            value={this.state.Companydescription.customer_category}
                                                                            disabled
                                                                            name="customercategory"
                                                                            placeholder="Customer Category"
                                                                            type="text"
                                                                            // errorMessage="Please Provide Contact Person Name"
                                                                            className="form-control"
                                                                            // validate={{ required: { value: true } }}
                                                                            id="validationCustom01"
                                                                        />
                                                                    </Col>
                                                                    <Col lg="4">
                                                                        <Label
                                                                            className="form-label"
                                                                            htmlFor="validationCustom01"
                                                                        >
                                                                            Customer Type
                                                                            <span style={{ color: "#ff0000" }}>*</span>
                                                                        </Label>
                                                                        <AvField
                                                                            value={this.state.Companydescription.customer_type}
                                                                            disabled
                                                                            name="customertype"
                                                                            placeholder="Customer Type"
                                                                            type="text"
                                                                            // errorMessage="Please Provide Contact Person Name"
                                                                            className="form-control"
                                                                            // validate={{ required: { value: true } }}
                                                                            id="validationCustom01"
                                                                        />
                                                                    </Col>
                                                                    <Col lg="4">
                                                                        <Label
                                                                            className="form-label"
                                                                            htmlFor="validationCustom01"
                                                                        >
                                                                            Customer Field Description
                                                                            {/* <span style={{ color: "#ff0000" }}>*</span> */}
                                                                        </Label>
                                                                        <AvField
                                                                            value={this.state.Companydescription.customer_field_description}
                                                                            // disabled
                                                                            name="customerfielddescription"
                                                                            placeholder="Customer Type"
                                                                            type="select"
                                                                            // errorMessage="Please Provide Customer Field Description"
                                                                            className="form-control"
                                                                            // validate={{ required: { value: true } }}
                                                                            id="validationCustom01"
                                                                        >
                                                                            <option value={""} >Select Field Description</option>
                                                                            <option value={"Other"} >Other</option>
                                                                            <option value={"Manufacturing"} >Manufacturing</option>
                                                                            <option value={"Service"} >Service</option>
                                                                        </AvField>
                                                                    </Col>
                                                                </>
                                                            )}
                                                            <Col lg="4">
                                                                <Label
                                                                    className="form-label"
                                                                    htmlFor="validationCustom01"
                                                                >
                                                                    Ownership Type
                                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                                </Label>
                                                                <AvField
                                                                    name="ownershiptype"
                                                                    placeholder="Ownership Type"
                                                                    type="select"
                                                                    // errorMessage="Please Provide Contact Person Name"
                                                                    className="form-control"
                                                                    // validate={{ required: { value: true } }}
                                                                    id="validationCustom01"
                                                                >
                                                                    <option value={""} >Select Ownership type</option>
                                                                    <option value={"Other"} >Other</option>
                                                                    {this.state.ownershiplist.map((item) => {
                                                                        return (
                                                                            <option value={item.id}>{item.name}</option>

                                                                        );
                                                                    })}
                                                                </AvField>
                                                            </Col>
                                                        </Row>
                                                        <div className="d-flex justify-content-between mt-3">
                                                            <Button color="primary" type="submit" className={this.state.activeTab === 1 ? "previous disabled" : "previous"}>Previous</Button>
                                                            <Button color="primary" type="submit" style={{ float: "right" }}>Next</Button>
                                                        </div>
                                                    </AvForm>
                                                </div>
                                            </TabPane>
                                            <TabPane tabId={3}>
                                                <div>
                                                    <AvForm
                                                        className="needs-validation"
                                                        onValidSubmit={this.handleSubmit}
                                                    // onSubmit={this.submitStep1}
                                                    >
                                                        <Row>
                                                            <Col lg="4" className="d-inline">
                                                                <Label
                                                                    className="form-label"
                                                                    htmlFor="validationCustom04"
                                                                >
                                                                    Select Contact Person
                                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                                </Label>
                                                                <AvField
                                                                    required={true}
                                                                    name="selectedcontactperson"
                                                                    type="select"
                                                                    id="validationCustom04"
                                                                    // value={this.state.selectedleadreference}
                                                                    errorMessage="Please Select a Contact Person."
                                                                    validate={{ required: { value: true } }}
                                                                    className="form-control"
                                                                    onChange={(e) => {
                                                                        this.setState({
                                                                            selectedcontactperson: e.target.value,
                                                                        });
                                                                        if (e.target.value != "") {
                                                                            this.SearchContactPersonById(e.target.value)
                                                                        }
                                                                    }}
                                                                >
                                                                    <option value={""} >Select Contact Person</option>
                                                                    <option value={""} >Other</option>
                                                                    {this.state.contactpersonlist.map((item) => {
                                                                        return (
                                                                            <option value={item.id}>{item.first_name + " " + item.last_name}</option>

                                                                        );
                                                                    })}
                                                                </AvField>
                                                            </Col>

                                                            {this.state.selectedcontactperson != "" && (
                                                                <>
                                                                    <Col lg="4">
                                                                        <Label
                                                                            className="form-label"
                                                                            htmlFor="validationCustom01"
                                                                        >
                                                                            Contact Person Phone No.
                                                                            <span style={{ color: "#ff0000" }}>*</span>
                                                                        </Label>
                                                                        <AvField
                                                                            value={this.state.ContactPersonDescription.mobile_no_1}
                                                                            disabled
                                                                            name="referenceusername"
                                                                            placeholder="Contact Person No."
                                                                            type="text"
                                                                            // errorMessage="Please Provide Contact Person Name"
                                                                            className="form-control"
                                                                            // validate={{ required: { value: true } }}
                                                                            id="validationCustom01"
                                                                        />
                                                                    </Col>
                                                                    <Col lg="4">
                                                                        <Label
                                                                            className="form-label"
                                                                            htmlFor="validationCustom01"
                                                                        >
                                                                            Contact Person Designation
                                                                            <span style={{ color: "#ff0000" }}>*</span>
                                                                        </Label>
                                                                        <AvField
                                                                            value={this.state.ContactPersonDescription.designation_name}
                                                                            disabled
                                                                            name="referenceusername"
                                                                            placeholder="Contact Person Designation."
                                                                            type="text"
                                                                            // errorMessage="Please Provide Contact Person Designation"
                                                                            className="form-control"
                                                                            // validate={{ required: { value: true } }}
                                                                            id="validationCustom01"
                                                                        />
                                                                    </Col>
                                                                    <Col lg="4">
                                                                        <Label
                                                                            className="form-label"
                                                                            htmlFor="validationCustom01"
                                                                        >
                                                                            Contact Person Department
                                                                            <span style={{ color: "#ff0000" }}>*</span>
                                                                        </Label>
                                                                        <AvField
                                                                            value={this.state.ContactPersonDescription.department_name}
                                                                            disabled
                                                                            name="referenceusername"
                                                                            placeholder="Contact Person Department."
                                                                            type="text"
                                                                            // errorMessage="Please Provide Contact Person Department"
                                                                            className="form-control"
                                                                            // validate={{ required: { value: true } }}
                                                                            id="validationCustom01"
                                                                        />
                                                                    </Col></>
                                                            )}
                                                        </Row>
                                                        <div className="d-flex justify-content-between mt-3">
                                                            <Button color="primary" type="submit" className={this.state.activeTab === 1 ? "previous disabled" : "previous"}>Previous</Button>
                                                            <Button color="primary" type="submit" style={{ float: "right" }}>Next</Button>
                                                        </div>
                                                    </AvForm>
                                                </div>
                                            </TabPane>
                                            <TabPane tabId={4}>
                                                <div>
                                                    <AvForm
                                                        className="needs-validation"
                                                        onValidSubmit={this.handleSubmit}
                                                    // onSubmit={this.submitStep1}
                                                    >
                                                        {/* <Row>
                                                            <Col lg="12">
                                                                <Label
                                                                    className="form-label"
                                                                    htmlFor="validationCustom01"
                                                                >
                                                                    Upload Document
                                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                                </Label>
                                                                <Dropzone
                                                                    onDrop={acceptedFiles =>
                                                                        this.handleAcceptedFiles(acceptedFiles)
                                                                    }
                                                                >
                                                                    {({ getRootProps, getInputProps }) => (
                                                                        <div className="dropzone">
                                                                            <div
                                                                                className="dz-message needsclick"
                                                                                {...getRootProps()}
                                                                            >
                                                                                <input {...getInputProps()} />
                                                                                <div className="mb-3">
                                                                                    <i className="display-4 text-muted ri-upload-cloud-2-line"></i>
                                                                                </div>
                                                                                <h4>Drop files here or click to upload.</h4>
                                                                            </div>
                                                                        </div>
                                                                    )}
                                                                </Dropzone>
                                                                <div
                                                                    className="dropzone-previews mt-3"
                                                                    id="file-previews"
                                                                >
                                                                    {this.state.selectedFiles.map((f, i) => {
                                                                        return (
                                                                            <Card
                                                                                className="mt-1 mb-0 shadow-none border dz-processing dz-image-preview dz-success dz-complete"
                                                                                key={i + "-file"}
                                                                            >
                                                                                <div className="p-2">
                                                                                    <Row className="align-items-center">
                                                                                        <Col className="col-auto">
                                                                                            <img
                                                                                                data-dz-thumbnail=""
                                                                                                height="80"
                                                                                                className="avatar-sm rounded bg-light"
                                                                                                alt={f.name}
                                                                                                src={f.preview}
                                                                                            />
                                                                                        </Col>
                                                                                        <Col>
                                                                                            <Link
                                                                                                to="#"
                                                                                                className="text-muted fw-bold"
                                                                                            >
                                                                                                {f.name}
                                                                                            </Link>
                                                                                            <p className="mb-0">
                                                                                                <strong>{f.formattedSize}</strong>
                                                                                            </p>
                                                                                        </Col>
                                                                                    </Row>
                                                                                </div>
                                                                            </Card>
                                                                        );
                                                                    })}
                                                                </div>
                                                            </Col>
                                                        </Row>
                                                        <Row>
                                                            <Col lg="6">
                                                                <Label
                                                                    className="form-label"
                                                                    htmlFor="validationCustom01"
                                                                >
                                                                    Document Type
                                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                                </Label>
                                                                <AvField
                                                                    name="documenttype"
                                                                    placeholder="Document Type"
                                                                    type="select"
                                                                    errorMessage="Please Provide Document Type"
                                                                    className="form-control"
                                                                    validate={{ required: { value: true } }}
                                                                    id="validationCustom01"
                                                                >
                                                                    <option value={""} >Select Document Type</option>
                                                                    <option value={"image"} >Image</option>
                                                                    <option value={"pdf"} >PDF</option>
                                                                </AvField>
                                                            </Col>
                                                            <Col lg="6">
                                                                <Label
                                                                    className="form-label"
                                                                    htmlFor="validationCustom01"
                                                                >
                                                                    Document Name
                                                                    <span style={{ color: "#ff0000" }}>*</span>
                                                                </Label>
                                                                <AvField
                                                                    name="documentname"
                                                                    placeholder="Document Name"
                                                                    type="text"
                                                                    errorMessage="Please Provide Document Name"
                                                                    className="form-control"
                                                                    validate={{ required: { value: true } }}
                                                                    id="validationCustom01"
                                                                />
                                                            </Col>
                                                        </Row> */}

                                                        <Row>
                                                            <div className="table-responsive">
                                                                <Table className="mb-3 table-nowrap">
                                                                    <thead className="bg-light">
                                                                        <tr>
                                                                            <th>File Name</th>
                                                                            <th>File Type</th>
                                                                            <th>File</th>
                                                                            <th>Actions</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        {this.state.rows.map((item, index) => (
                                                                            <tr key={index}>
                                                                                <td>
                                                                                    <AvField
                                                                                        name={`FileName-${index}`}
                                                                                        placeholder="File Name"
                                                                                        type="text"
                                                                                        errorMessage="Please Provide File Name"
                                                                                        className="form-control"
                                                                                        onChange={e => {
                                                                                            const { rows } = this.state;
                                                                                            rows[index].document_name = e.target.value;
                                                                                            this.setState({ rows });
                                                                                        }}
                                                                                    />
                                                                                </td>
                                                                                <td>
                                                                                    <AvField
                                                                                        name={`document_type-${index}`}
                                                                                        placeholder="File Type"
                                                                                        type="select"
                                                                                        errorMessage="Please Provide File Type"
                                                                                        className="form-control"
                                                                                        onChange={e => {
                                                                                            const { rows } = this.state;
                                                                                            rows[index].document_type = e.target.value;
                                                                                            this.setState({ rows });
                                                                                        }}
                                                                                    >
                                                                                        <option value={""} >Select Document Type</option>
                                                                                        <option value={"image"} >Image</option>
                                                                                        <option value={"pdf"} >PDF</option>
                                                                                    </AvField>
                                                                                </td>
                                                                                <td>
                                                                                    <h6>
                                                                                        <input
                                                                                            type="file"
                                                                                            onChange={(e) => this.handleFileChange(e, index)}
                                                                                        />
                                                                                    </h6>
                                                                                </td>
                                                                                <td>
                                                                                    <Button color="primary" onClick={this.addRow}>
                                                                                        Add Row
                                                                                    </Button>
                                                                                    <Button
                                                                                        onClick={() => this.deleteRow(index)}
                                                                                        style={{
                                                                                            backgroundColor: "white",
                                                                                            border: "none",
                                                                                            marginLeft: "5px",
                                                                                        }}
                                                                                    >
                                                                                        <RiDeleteBin6Line style={{ color: "red" }} />
                                                                                    </Button>
                                                                                </td>
                                                                            </tr>
                                                                        ))}
                                                                    </tbody>
                                                                </Table>
                                                            </div>
                                                        </Row>
                                                        <div className="d-flex justify-content-between mt-3">
                                                            <Button color="primary" type="submit" className={this.state.activeTab === 1 ? "previous disabled" : "previous"}>Previous</Button>
                                                            <Button color="primary" type="submit" style={{ float: "right" }}>Next</Button>
                                                        </div>
                                                    </AvForm>
                                                </div>
                                            </TabPane>
                                            <TabPane tabId={5}>
                                                <div className="row justify-content-center">
                                                    <Col lg="6">
                                                        <div className="text-center">
                                                            <div className="mb-4">
                                                                <i className="mdi mdi-check-circle-outline text-success display-4"></i>
                                                            </div>
                                                            <div>
                                                                <h5>Confirm Detail</h5>
                                                                <p className="text-muted">If several languages coalesce, the grammar of the resulting</p>
                                                            </div>
                                                        </div>
                                                    </Col>
                                                </div>
                                            </TabPane>
                                        </TabContent>
                                        {/* <ul className="pager wizard twitter-bs-wizard-pager-link">
                                            <li className={this.state.activeTab === 1 ? "previous disabled" : "previous"}><Link to="#" onClick={() => { this.toggleTab(this.state.activeTab - 1); }}>Previous</Link></li>
                                            <li className={this.state.activeTab === 5 ? "next disabled" : "next"}><Link to="#" onClick={() => { this.toggleTab(this.state.activeTab + 1); }}>Next</Link></li>
                                            <li className={this.state.activeTab === 5 ? "next disabled" : "next"}>
                                                <Button type="submit" onClick={() => { this.toggleTab(this.state.activeTab + 1) }}> Next</Button>
                                            </li>
                                        </ul> */}
                                    </div>
                                </CardBody>
                            </Card>
                        </Col>
                    </Container>
                </div>
            </React.Fragment >
        );
    };
};

export default MarketLeadForWizard;
