export const FORGET_USER = 'login_user';
export const FORGET_USER_SUCCESSFUL = 'forget_user_successfull';

export const FORGET_PASSWORD_API_FAILED = 'FORGET_PASSWORD_API_FAILED';